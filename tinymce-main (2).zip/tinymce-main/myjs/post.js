var resources = [
    'filepond.css',
    'filepond.js',
    'filepond-plugin-file-encode.min.js',
    'filepond-plugin-file-validate-type.min.js',
    'filepond-plugin-file-validate-size.min.js',
    'filepond-plugin-image-exif-orientation.min.js',
    'filepond-plugin-image-preview.min.css',
    'filepond-plugin-image-preview.min.js',
    'filepond-plugin-image-crop.min.js',
    'filepond-plugin-image-resize.min.js',
    'filepond-plugin-image-transform.min.js',
    // for use with Pintura Image Editor
    'filepond-plugin-file-poster.min.css',
    'filepond-plugin-file-poster.min.js',
    'filepond-plugin-image-editor.min.js',

].map(function (resource) { return '/lib_file/' + resource });
window.pond = null;

loadResources(resources).then(function () {

    // register plugins
    FilePond.registerPlugin(
        FilePondPluginFileEncode,
        FilePondPluginFileValidateType,
        FilePondPluginFileValidateSize,
        FilePondPluginImageExifOrientation,
        FilePondPluginImagePreview,
        FilePondPluginImageCrop,
        FilePondPluginImageResize,
        FilePondPluginImageTransform,
        FilePondPluginFilePoster,
        FilePondPluginImageEditor /* for use with Pintura */
    );

    // override default options
    FilePond.setOptions({
        dropOnPage: true,
        dropOnElement: true,
        imageEditorInstantEdit: true,
        labelIdle: '<div class="d-flex flex-column align-items-center"><span class="fas fa-plus mb-2"></span><span class="filepond--label-action">Nhấn hoặc kéo thả tập tin vào đây</span></div>',
        labelInvalidField: 'Trường chứa các tệp không hợp lệ',
        labelFileWaitingForSize: 'Chờ kích thước',
        labelFileSizeNotAvailable: 'Kích thước không khả dụng',
        labelFileLoading: 'Đang tải...',
        labelFileLoadError: 'Lỗi trong quá trình tải',
        labelFileProcessing: 'Đang tải lên...',
        labelFileProcessingComplete: 'Tải lên hoàn chỉnh',
        labelFileProcessingAborted: 'Tải lên bị hủy',
        labelFileProcessingError: 'Lỗi trong quá trình tải lên',
        labelFileProcessingRevertError: 'Lỗi trong quá trình hoàn nguyên',
        labelFileRemoveError: 'Lỗi trong khi loại bỏ',
        labelTapToCancel: 'Nhấn để hủy',
        labelTapToRetry: 'Nhấn để thử lại',
        labelTapToUndo: 'Nhấn để hoàn tác',
        labelButtonRemoveItem: 'Xóa',
        labelButtonAbortItemLoad: 'Hủy bỏ',
        labelButtonRetryItemLoad: 'Thử lại',
        labelButtonAbortItemProcessing: 'Hủy',
        labelButtonUndoItemProcessing: 'Hoàn tác',
        labelButtonRetryItemProcessing: 'Thử lại',
        labelButtonProcessItem: 'Tải lên',
    });

    // create splash file pond element
    var fields = [].slice.call(document.querySelectorAll('input[name="filepond"]'));
    var ponds = fields.map(function (field, index) {
        return FilePond.create(field, {
            credits: false,
            server: {
                process: (fieldName, file, metadata, load, error, progress, abort, transfer, options) => {
                    const formData = new FormData();
                    formData.append(fieldName, file, file.name);
                    const request = new XMLHttpRequest();
                    request.open('POST', `/myadmin/posts/upload_file`);
                    request.upload.onprogress = (e) => {
                        progress(e.lengthComputable, e.loaded, e.total);
                    };

                    request.onload = function () {
                        if (request.status >= 200 && request.status < 300) {
                            load(request.responseText);
                            if (request.response != undefined && request.response != null && request.response != "") {
                                var data = JSON.parse(request.response); 
                                $('.imagePreview').css('background-image', 'none');
                                $('#file_name_post').val(data.file.file_name);
                            }
                        } else {
                            error('Error');
                        }
                    };

                    request.send(formData);
                    return {
                        abort: () => {
                            request.abort();
                            abort();
                        },
                    };
                },
                revert: (uniqueFileId, load, error) => {
                    const formData = new FormData();
                    if (uniqueFileId != undefined && uniqueFileId != null && uniqueFileId != "") {
                        var data = JSON.parse(uniqueFileId);
                        formData.append('id_mediafile', data.file.id);
                        $(`#render_file_id_${data.file.id}`).remove();
                    }
                    const request = new XMLHttpRequest();
                    request.open('DELETE', `/myadmin/posts/remove_file`);

                    request.onload = function () {
                        if (request.status >= 200 && request.status < 300) {
                            load(request.responseText);
                            if (request.response != undefined && request.response != null && request.response != "") {
                                var data = JSON.parse(request.response); 
                            }
                        } else {
                            error('Error');
                        }
                    };

                    request.send(formData);
                    error('Error');
                    load();
                },
                remove: (source, load, error) => {
                    error('Error');
                    load();
                },
            },
            allowFilePoster: false,
            allowImageEditor: false,
        });
    });

    // add warning to multiple files pond
    var pondDemoMultiple = ponds[0];
    var pondMultipleTimeout;
    pondDemoMultiple.onwarning = function () {
        var container = pondDemoMultiple.element.parentNode;
        var error = container.querySelector('p.filepond--warning');
        if (!error) {
            error = document.createElement('p');
            error.className = 'filepond--warning';
            error.textContent = 'The maximum number of files is 3';
            container.appendChild(error);
        }
        requestAnimationFrame(function () {
            error.dataset.state = 'visible';
        });
        clearTimeout(pondMultipleTimeout);
        pondMultipleTimeout = setTimeout(function () {
            error.dataset.state = 'hidden';
        }, 10000);
    };
    pondDemoMultiple.onaddfile = function () {
        clearTimeout(pondMultipleTimeout);
        var container = pondDemoMultiple.element.parentNode;
        var error = container.querySelector('p.filepond--warning');
        if (error) {
            error.dataset.state = 'hidden';
        }
    };
    pondDemoMultiple.on('processfile', function(error, file) {
        $('.filepond--file-action-button.filepond--action-edit-item').click(function() {
            $('#loading').css('display', 'flex');
            $('link#dental-clinic-main-css').attr('href', '');
            setTimeout(() => {   
                $('#loading').css('display', 'none');
                $('.PinturaNavSet button.PinturaButton.PinturaButtonIconOnly[title="Close"]').click(function() {
                    $('link#dental-clinic-main-css').attr('href', '/css/style.css');
                });
                
                $('.PinturaNavGroup button.PinturaButton.PinturaButtonExport[title="Done"]').click(function() {
                    $('link#dental-clinic-main-css').attr('href', '/css/style.css');
                });
            }, 1000);
        });
    });

    // set top pond
    pond = ponds[0];
    document.dispatchEvent(new CustomEvent('filepond:ready'))
});

var loadPintura = (pintura) => {
    var pondMultiple = FilePond.find(document.querySelector(`#filepond_multiple`));

    // register plugins to use
    pintura.setPlugins(
        pintura.plugin_crop,
        pintura.plugin_finetune,
        pintura.plugin_filter,
    );

    // not needed when using Pintura Image Editor
    pondMultiple.allowImagePreview = false;
    pondMultiple.allowImageTransform = false;
    pondMultiple.allowImageResize = false;
    pondMultiple.allowImageCrop = false;
    pondMultiple.allowImageExifOrientation = false;

    // set Pintura Image Editor props
    pondMultiple.allowFilePoster = true;
    pondMultiple.allowImageEditor = true;
    // pondMultiple.imageEditorInstantEdit = true;

    // FilePond generic properties
    pondMultiple.filePosterMaxHeight = 256;
    pondMultiple.imageEditor = {
        legacyDataToImageState: pintura.legacyDataToImageState,
        createEditor: pintura.openEditor,
        imageReader: [pintura.createDefaultImageReader],
        imageWriter: [
            pintura.createDefaultImageWriter,
            {
                // Cấu hình chất lượng ảnh
                targetSize: {
                    width: 800,
                    height: 800,
                },
            },
        ],
        imageProcessor: pintura.processImage,
        editorOptions: {
            ...pintura.getEditorDefaults(),
            imageCropAspectRatio: 16 / 9,
            cropEnableButtonRotateRight: true,
            cropEnableButtonFlipVertical: true,
            // cropSelectPresetOptions: [
            //     [undefined, 'Custom'],
            //     [1, 'Square'],

            //     // shown when cropSelectPresetFilter is set to 'landscape'
            //     [2 / 1, '2:1'],
            //     [3 / 2, '3:2'],
            //     [4 / 3, '4:3'],
            //     [16 / 10, '16:10'],
            //     [16 / 9, '16:9'],

            //     // shown when cropSelectPresetFilter is set to 'portrait'
            //     [1 / 2, '1:2'],
            //     [2 / 3, '2:3'],
            //     [3 / 4, '3:4'],
            //     [10 / 16, '10:16'],
            //     [9 / 16, '9:16'],
            // ],
        },
    };
}

loadResources(['/lib_file/pintura.css']).then(function () {
    import('/lib_file/pintura.js').then(pintura => {
        if (window.pond) return loadPintura(pintura);
        else {
            document.addEventListener('filepond:ready', () => {
                loadPintura(pintura)
            })
        }
    })
});

$('.choices').addClass('form-select');
$('#re_crop_image').addClass('d-none');

// JavaScript
$(function () {
    $("#submit-save").click(function () {
        $('#is_published').val(false);
        var srcValue = $('#file_name_post').val();
        if ((srcValue != null && srcValue != "") || linkImage != "") {
            $('.imagePreview').css('border', '1px dashed #979797');
            $('.error-file').text(""); 
        } else {
            $('.error-file').text('Vui lòng thêm hình cho bài viết');
            $('.imagePreview').css('border', '1px dashed red');
            return
        }
        var select_tag = $('#select_tag').val();
        if (!$.isEmptyObject(select_tag)) {
            $('.choices.form-select').removeClass('error_valid mb-0');
            $('.error-select').text(""); 
        } else {
            $('.error-select').text('Vui lòng chọn nhãn');
            $('.choices.form-select').addClass('error_valid mb-0');
            return;
        }
        $('#buh_form_post').submit();
    });

    $("#submit-save-public").click(function () {
        $('#is_published').val(true);
        var srcValue = $('#file_name_post').val();
        if ((srcValue != null && srcValue != "") || linkImage != "") {
            $('.imagePreview').css('border', '1px dashed #979797');
            $('.error-file').text(""); 
        } else {
            $('.error-file').text('Vui lòng thêm hình cho bài viết');
            $('.imagePreview').css('border', '1px dashed red');
            return
        }
        var select_tag = $('#select_tag').val();
        if (!$.isEmptyObject(select_tag)) {
            $('.choices.form-select').removeClass('error_valid mb-0');
            $('.error-select').text(""); 
        } else {
            $('.error-select').text('Vui lòng chọn nhãn');
            $('.choices.form-select').addClass('error_valid mb-0');
            return;
        }
        $('#buh_form_post').submit();
    });

    $(".form_post").validate({
        rules: {
            "title_post": {
                required: true,
            },
            // "short_content": {
            //     required: true,
            // },
            "url": {
                required: true,
                remote: {
                    url: "/myadmin/posts/check_url",
                    type: "post",
                    data: {
                        url: function () {
                            return $("#url").val();
                        },
                        url_old: url_old,
                    }
                }
            }
        },
        messages: {
            "title_post": {
                required: "Vui lòng nhập tiêu đề",
            },
            // "short_content": {
            //     required: "Vui lòng nhập mô tả ngắn",
            // },
            "url": {
                required: "Vui lòng nhập URL",
                remote: "URL đã tồn tại trong hệ thống"
            }
        },
        errorPlacement: function(error, element) {
            if (element.attr("name") == "url") {
                error.insertAfter(element.closest(".input-group"));
            } else {
                error.insertAfter(element);
            }
        }
    });
    
    $('#title_post').on('keydown', function (event) {
        if (event.keyCode === 13) {
            event.preventDefault();
        }
    });

});

const image_upload_handler = (blobInfo, progress) => new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.withCredentials = false;
    xhr.open('POST', "/posts/upload_file_tinymce");

    xhr.upload.onprogress = (e) => {
        progress(e.loaded / e.total * 100);
    };

    xhr.onload = () => {
        if (xhr.status === 403) {
            reject({ message: 'HTTP Error: ' + xhr.status, remove: true });
            return;
        }

        if (xhr.status < 200 || xhr.status >= 300) {
            reject('HTTP Error: ' + xhr.status);
            return;
        }

        const json = JSON.parse(xhr.responseText);

        if (!json || typeof json.location != 'string') {
            reject('Invalid JSON: ' + xhr.responseText);
            return;
        }

        resolve(json.location);
    };

    xhr.onerror = () => {
        reject('Image upload failed due to a XHR Transport error. Code: ' + xhr.status);
    };

    const formData = new FormData();
    formData.append('file', blobInfo.blob(), blobInfo.filename());
    formData.append("authenticity_token", document.querySelector('meta[name="csrf-token"]').getAttribute('content'));

    xhr.send(formData);
});

function initTinymce() {
    var tinymceOptions = {
        language_url: '/mywork/myjs/vi.js',
        language: 'vi',
        plugins: 'lists advlist anchor autolink autosave autoresize charmap code codesample directionality emoticons fullscreen image importcss insertdatetime link lists media nonbreaking pagebreak preview quickbars save searchreplace table template visualblocks visualchars wordcount',
        toolbar1: 'undo redo | blocks fontsize | align lineheight | bold italic underline strikethrough forecolor backcolor',
        toolbar2: 'template |image checklist numlist bullist table mergetags | addcomment showcomments | spellcheckdialog a11ycheck typography | link media indent outdent',
        table_toolbar: 'tableprops tabledelete | tableinsertrowbefore tableinsertrowafter tabledeleterow | tableinsertcolbefore tableinsertcolafter tabledeletecol',
        min_height: 500,
        images_upload_handler: image_upload_handler,
        file_picker_types: 'image',
        file_picker_callback: (cb, value, meta) => {
            const input = document.createElement('input');
            input.setAttribute('type', 'file');
            input.setAttribute('accept', 'image/*');

            input.addEventListener('change', (e) => {
                const file = e.target.files[0];

                const reader = new FileReader();
                reader.addEventListener('load', () => {
                    /*
                      Note: Now we need to register the blob in TinyMCEs image blob
                      registry. In the next release this part hopefully won't be
                      necessary, as we are looking to handle it internally.
                    */
                    const id = 'blobid' + (new Date()).getTime();
                    const blobCache = tinymce.activeEditor.editorUpload.blobCache;
                    const base64 = reader.result.split(',')[1];
                    const blobInfo = blobCache.create(id, file, base64);
                    blobCache.add(blobInfo);

                    /* call the callback and populate the Title field with the file name */
                    cb(blobInfo.blobUri(), { title: file.name });
                });
                reader.readAsDataURL(file);
            });

            input.click();
        },
        relative_urls: false,
        remove_script_host: false,
        color_map: [
            '#BFEDD2', 'Light Green',
            '#FBEEB8', 'Light Yellow',
            '#F8CAC6', 'Light Red',
            '#ECCAFA', 'Light Purple',
            '#C2E0F4', 'Light Blue',

            '#2DC26B', 'Green',
            '#F1C40F', 'Yellow',
            '#E03E2D', 'Red',
            '#B96AD9', 'Purple',
            '#3598DB', 'Blue',

            '#169179', 'Dark Turquoise',
            '#E67E23', 'Orange',
            '#BA372A', 'Dark Red',
            '#843FA1', 'Dark Purple',
            '#236FA1', 'Dark Blue',

            '#ECF0F1', 'Light Gray',
            '#CED4D9', 'Medium Gray',
            '#95A5A6', 'Gray',
            '#7E8C8D', 'Dark Gray',
            '#34495E', 'Navy Blue',

            '#000000', 'Black',
            '#ffffff', 'White'
        ],
    }

    tinymce.init({
        ...{ selector: '#content' },
        ...tinymceOptions
    });

    tinymce.init({
        ...{ selector: '#content_en' },
        ...tinymceOptions
    });

}

initTinymce();

$('#url').on('input', function () {
    var snameValue = $(this).val();
    var scodeValue = removeVietnameseTones(snameValue).toLowerCase();
    $('#url').val(scodeValue);
});

function removeVietnameseTones(str) {
    str = str.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g, "a");
    str = str.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/g, "e");
    str = str.replace(/ì|í|ị|ỉ|ĩ/g, "i");
    str = str.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/g, "o");
    str = str.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/g, "u");
    str = str.replace(/ỳ|ý|ỵ|ỷ|ỹ/g, "y");
    str = str.replace(/đ/g, "d");
    str = str.replace(/À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ/g, "A");
    str = str.replace(/È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ/g, "E");
    str = str.replace(/Ì|Í|Ị|Ỉ|Ĩ/g, "I");
    str = str.replace(/Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ/g, "O");
    str = str.replace(/Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ/g, "U");
    str = str.replace(/Ỳ|Ý|Ỵ|Ỷ|Ỹ/g, "Y");
    str = str.replace(/Đ/g, "D");
    // Some system encode vietnamese combining accent as individual utf-8 characters
    // Một vài bộ encode coi các dấu mũ, dấu chữ như một kí tự riêng biệt nên thêm hai dòng này
    str = str.replace(/\u0300|\u0301|\u0303|\u0309|\u0323/g, ""); // ̀ ́ ̃ ̉ ̣  huyền, sắc, ngã, hỏi, nặng
    str = str.replace(/\u02C6|\u0306|\u031B/g, ""); // ˆ ̆ ̛  Â, Ê, Ă, Ơ, Ư
    // Remove extra spaces
    // Bỏ các khoảng trắng liền nhau
    str = str.trim().replace(/\s+/g, " ");
    // Remove punctuations
    // Bỏ dấu câu, kí tự đặc biệt
    str = str.replace(/!|@|%|\^|\*|\(|\)|\+|\=|\<|\>|\?|\/|,|\.|\:|\;|\'|\"|\&|\#|\[|\]|~|\$|_|`|-|{|}|\||\\/g, " ");
    str = str.replace(/ /g, '-');
    str = str.toLowerCase();
    return str;
}
