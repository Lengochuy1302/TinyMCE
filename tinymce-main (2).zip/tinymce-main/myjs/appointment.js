$().ready(function() {
	$("#form_booking").validate({
		rules: {
			"number_phone": {
				required: true,
			},
			"time_order": {
				required: true,
			},
			"last_name": {
				required: true,
			},
			"first_name": {
				required: true,
			},
		},
    messages: {
			"number_phone": {
				required: "Bắt buộc nhập số điện thoại",
			},
			"time_order": {
				required: "Vui lòng chọn giờ",
			},
			"last_name": {
				required: "Bắt buộc nhập họ",
			},
			"first_name": {
				required: "Bắt buộc nhập tên",
			},
		},
	});

  flatpickr(".datetimepicker", {
    dateFormat: "d/m/Y",
    defaultDate: "today",
    minDate: "today",
    locale: {
      firstDayOfWeek: 1, // bắt đầu từ thứ 2
      weekdays: {
        shorthand: ["CN", "T2", "T3", "T4", "T5", "T6", "T7"],
        longhand: [
          "Chủ nhật",
          "Thứ hai",
          "Thứ ba",
          "Thứ tư",
          "Thứ năm",
          "Thứ sáu",
          "Thứ bảy",
        ],
      },
      months: {
        shorthand: [
          "Thg 1",
          "Thg 2",
          "Thg 3",
          "Thg 4",
          "Thg 5",
          "Thg 6",
          "Thg 7",
          "Thg 8",
          "Thg 9",
          "Thg 10",
          "Thg 11",
          "Thg 12",
        ],
        longhand: [
          "Tháng 1",
          "Tháng 2",
          "Tháng 3",
          "Tháng 4",
          "Tháng 5",
          "Tháng 6",
          "Tháng 7",
          "Tháng 8",
          "Tháng 9",
          "Tháng 10",
          "Tháng 11",
          "Tháng 12",
        ],
      },
    },
  //   onValueUpdate: function(selectedDates, dateStr, instance) {
  //     $('#after_change_date').text(dateStr);
  // }
  });

  $(".valid").click(function() {     
        $("#time-select").css("color", "#000000");    
  });

  $("#btn_order_view").click(function() {     
      if($('input[type=radio][name=time_order]:checked').length == 0)
      {
        $("#time-select").css("color", "red");
        $("#time-select").animate({'zoom': 1.05}, 400).delay(100).animate({'zoom': 1}, 400)
      }
      else
      {
        $("#form_booking").submit()
        
      }      
  });
});