  
    $(document).ready(function() {
      $("#show_hide_password a").on('click', function(event) {
          event.preventDefault();
          if($('#show_hide_password input').attr("type") == "text"){
              $('#show_hide_password input').attr('type', 'password');
              $('#show_hide_password i').addClass( "fa-eye-slash" );
              $('#show_hide_password i').removeClass( "fa-eye" );
          }else if($('#show_hide_password input').attr("type") == "password"){
              $('#show_hide_password input').attr('type', 'text');
              $('#show_hide_password i').removeClass( "fa-eye-slash" );
              $('#show_hide_password i').addClass( "fa-eye" );
          }
      });
      });
      
      $(document).ready(function() {
          $("#show_hide_password_pwd a").on('click', function(event) {
              event.preventDefault();
              if($('#show_hide_password_pwd input').attr("type") == "text"){
                  $('#show_hide_password_pwd input').attr('type', 'password');
                  $('#show_hide_password_pwd i').addClass( "fa-eye-slash" );
                  $('#show_hide_password_pwd i').removeClass( "fa-eye" );
              }else if($('#show_hide_password_pwd input').attr("type") == "password"){
                  $('#show_hide_password_pwd input').attr('type', 'text');
                  $('#show_hide_password_pwd i').removeClass( "fa-eye-slash" );
                  $('#show_hide_password_pwd i').addClass( "fa-eye" );
              }
          });
          });
  
  
  function delete_loading_users(element){
    element.style.display = "none"
    element.previousElementSibling.style.display = "none"
    element.nextElementSibling.style.display = "block"
  }


  function closeFormAddUsers() {
    document.getElementById("form-add-users-container").style.display = "none";
    document.getElementById("users_id_add").value = "";
    document.getElementById("username_user").value = "";
    document.getElementById("firstname_user").value = "";
    document.getElementById("lastname_user").value = "";
    document.getElementById("email_user").value = "";     
      
  }

 

    document.getElementById("btn_add_new_users_buttton").addEventListener("click", function() {
    document.getElementById("btn_add_new_user_buttton").style.display = "none";
    document.getElementById("loading_button_user").style.display = "block";
  })

  $().ready(function() {
    $("#form_add_user").validate({
      rules: {
        "password_user": {
        },
        "re_password_user": {
          equalTo: "#password_user"
        },
      },
      messages: {
        "re_password_user": {
          equalTo: "Mật khẩu chưa khớp", 
        },
      },
      
    });
  });