const image_upload_handler = (blobInfo, progress) => new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.withCredentials = false;
    xhr.open('POST', "/posts/upload_file_tinymce");
  
    xhr.upload.onprogress = (e) => {
      progress(e.loaded / e.total * 100);
    };
  
    xhr.onload = () => {
      if (xhr.status === 403) {
        reject({ message: 'HTTP Error: ' + xhr.status, remove: true });
        return;
      }
  
      if (xhr.status < 200 || xhr.status >= 300) {
        reject('HTTP Error: ' + xhr.status);
        return;
      }
  
      const json = JSON.parse(xhr.responseText);
  
      if (!json || typeof json.location != 'string') {
        reject('Invalid JSON: ' + xhr.responseText);
        return;
      }
  
      resolve(json.location);
    };
  
    xhr.onerror = () => {
      reject('Image upload failed due to a XHR Transport error. Code: ' + xhr.status);
    };
  
    const formData = new FormData();
    formData.append('file', blobInfo.blob(), blobInfo.filename());
    formData.append("authenticity_token",document.querySelector('meta[name="csrf-token"]').getAttribute('content'));
  
    xhr.send(formData);
  });

function initTinymce(){
    var tinymceOptions = {
      language_url: '/mywork/myjs/vi.js',
      language: 'vi',
      plugins: 'lists advlist anchor autolink autosave autoresize charmap code codesample directionality emoticons fullscreen image importcss insertdatetime link lists media nonbreaking pagebreak preview quickbars save searchreplace table template visualblocks visualchars wordcount',
      toolbar1: 'undo redo | blocks fontsize | align lineheight | bold italic underline strikethrough forecolor backcolor',
      toolbar2: 'template |image checklist numlist bullist table mergetags | addcomment showcomments | spellcheckdialog a11ycheck typography | link media indent outdent',
      table_toolbar: 'tableprops tabledelete | tableinsertrowbefore tableinsertrowafter tabledeleterow | tableinsertcolbefore tableinsertcolafter tabledeletecol',
      content_style: 'body { font-family: "Source Serif 4", sans-serif; }',
      min_height: 500,
      images_upload_handler: image_upload_handler,
      file_picker_types: 'image',
      file_picker_callback: (cb, value, meta) => {
        const input = document.createElement('input');
        input.setAttribute('type', 'file');
        input.setAttribute('accept', 'image/*');
    
        input.addEventListener('change', (e) => {
          const file = e.target.files[0];
    
          const reader = new FileReader();
          reader.addEventListener('load', () => {
            /*
              Note: Now we need to register the blob in TinyMCEs image blob
              registry. In the next release this part hopefully won't be
              necessary, as we are looking to handle it internally.
            */
            const id = 'blobid' + (new Date()).getTime();
            const blobCache =  tinymce.activeEditor.editorUpload.blobCache;
            const base64 = reader.result.split(',')[1];
            const blobInfo = blobCache.create(id, file, base64);
            blobCache.add(blobInfo);
    
            /* call the callback and populate the Title field with the file name */
            cb(blobInfo.blobUri(), { title: file.name });
          });
          reader.readAsDataURL(file);
        });
    
        input.click();
      },
      relative_urls: false,
      remove_script_host: false,
      extended_valid_elements: 'svg[*],rect[*],circle[*],path[*],g[*],span[class],link[href|rel],style,script[src|type],label[*]',
      valid_elements : '*[*],+*[*]',
      custom_elements:"style,link,~link",
      formats: {
          removeformat: [
            {selector: '*', remove: 'all', split: true, expand: false, block_expand: true, deep_merge: true}
          ]
      },
      custom_formats: [
        {
          name: 'fontawesome',
          inline: 'span',
          classes: 'fa'
        }
      ], 
      init_instance_callback: function (editor) {
        var jqueryScript = "/myjs/bmtu/jquery.min.js";
        var jsPaths = [
          "/myjs/bmtu/bootstrap.bundle.min.js",
          "/myjs/bmtu/jquery.meanmenu.js",
          "/myjs/bmtu/owl.carousel.min.js",
          "/myjs/bmtu/carousel-thumbs.min.js",
          "/myjs/bmtu/jquery.magnific-popup.js",
          "/myjs/bmtu/aos.js",
          "/myjs/bmtu/odometer.min.js",
          "/myjs/bmtu/appear.min.js",
          "/myjs/bmtu/form-validator.min.js",
          "/myjs/bmtu/contact-form-script.js",
          "/myjs/bmtu/ajaxchimp.min.js",
          "/myjs/bmtu/custom.js",
          "/myjs/slick.min.js",
          "/myjs/bmtu/slider_customs.js"
        ];
    
        var loadScript = function (src) {
          return new Promise(function (resolve, reject) {
            var script = editor.dom.create('script', { src: src });
            script.onload = resolve;
            script.onerror = reject;
            editor.getDoc().head.appendChild(script);
          });
        };

        loadScript(jqueryScript)
          .then(function () {
            return jsPaths.reduce(function (prev, path) {
              return prev.then(function () {
                return loadScript(path);
              });
            }, Promise.resolve());
          })
          .catch(function (error) {
            console.error('Error loading scripts:', error);
          });
      },
      resize: true, 
      content_css_cors: true,
      content_css: [
        '/mystyle/bmtu/bootstrap.min.css',
        '/mystyle/bmtu/meanmenu.css',
        '/mystyle/bmtu/owl.carousel.min.css',
        '/mystyle/bmtu/owl.theme.default.min.css',
        '/mystyle/bmtu/magnific-popup.css',
        '/mystyle/bmtu/flaticon.css',
        '/mystyle/bmtu/remixicon.css',
        '/mystyle/bmtu/odometer.min.css',
        '/mystyle/bmtu/aos.css',
        '/mystyle/bmtu/style.css',
        '/mystyle/bmtu/dark.css',
        '/mystyle/bmtu/responsive.css',
        '/mystyle/bmtu/bmtu_1.css',
        '/mystyle/bmtu/bmtu_2.css',
        '/mystyle/bmtu/bmtu_3.css',
        '/mystyle/bmtu/bmtu_4.css',
        '/mystyle/bmtu/bmtu_5.css',
        '/mystyle/bmtu/bmtu_6.css',
        '/mystyle/bmtu/bmtu_7.css',
        '/mystyle/bmtu/bmtu_8.css',
        '/mystyle/bmtu/bmtu_9.css',
        '/mystyle/bmtu/bmtu_10.css',
        '/mystyle/bmtu/bmtu_11.css',
        '/mystyle/bmtu/bmtu_12.css',
        '/mystyle/bmtu/bmtu_13.css',
        '/mystyle/bmtu/bmtu_14.css',
        '/mystyle/bmtu/bmtu_15.css',
        '/mystyle/bmtu/bmtu_16.css',
        '/mystyle/bmtu/bmtu_17.css',
        '/mystyle/slick.min.css',
        '/mystyle/slick-theme.min.css',
        'https://fonts.googleapis.com/css?family=Source Serif 4',
      ],
      importcss_append: true,
      color_map: [
          '#BFEDD2', 'Light Green',
          '#FBEEB8', 'Light Yellow',
          '#F8CAC6', 'Light Red',
          '#ECCAFA', 'Light Purple',
          '#C2E0F4', 'Light Blue',
        
          '#2DC26B', 'Green',
          '#F1C40F', 'Yellow',
          '#E03E2D', 'Red',
          '#B96AD9', 'Purple',
          '#3598DB', 'Blue',
        
          '#169179', 'Dark Turquoise',
          '#E67E23', 'Orange',
          '#BA372A', 'Dark Red',
          '#843FA1', 'Dark Purple',
          '#236FA1', 'Dark Blue',
        
          '#ECF0F1', 'Light Gray',
          '#CED4D9', 'Medium Gray',
          '#95A5A6', 'Gray',
          '#7E8C8D', 'Dark Gray',
          '#34495E', 'Navy Blue',
        
          '#000000', 'Black',
          '#ffffff', 'White'
        ]
    }
    
    tinymce.init({
      ...{selector: '#content'},
      ...tinymceOptions
    });


    tinymce.init({
      ...{selector: '#content_en'},
      ...tinymceOptions
    });
  
}

initTinymce();

$('.choices').addClass('form-select');
$('#re_crop_image').addClass('d-none');

// JavaScript
$(function() {
    var cropper;
    var croppedImageFile;
    // show preview when file input changes
    $('#file').on('change', function() {
        $('#imagePreview').css('border', '1px dashed #979797'); 
        $('.error-file').text("");
        var input = $(this)[0];
        if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function(e) {
            // $('#re_crop_image').removeClass('d-none');
            $('#imagePreview').html('<img src="' + e.target.result + '">');
        }

        reader.readAsDataURL(input.files[0]);
        }
    });

    $('#imagePreview').on('drop', function(e) { 
        e.preventDefault(); 
        var files = e.originalEvent.dataTransfer.files; 
        const fileInput = document.getElementById('file');
        fileInput.files = files;
        processFiles(files);
    });
        
    $('#imagePreview').on('dragover', function(e) { 
        e.preventDefault(); 
        e.originalEvent.dataTransfer.dropEffect = 'copy';
    });
        
    function processFiles(files) { 
        $('#imagePreview').css('border', '1px dashed #979797'); 
        $('.error-file').text("");
        $.each(files, function(index, file) { 
        var reader = new FileReader(); 
        reader.onload = function(e) { 
            var dataUrl = e.target.result; 
            // $('#re_crop_image').removeClass('d-none');
            $('#imagePreview').html('<img src="' + dataUrl + '">');
        }; 
        reader.readAsDataURL(file);
        });
    }

    $( "#re_crop_image" ).click(function() {
        var input = $('#file')[0];
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            
            reader.onload = function(e) {
                var image = document.getElementById('image-crop-btmu');
                image.src = e.target.result;
                if (cropper) {
                    cropper.destroy();
                }
                $('#cropModal').addClass('show'); 
                cropper = new Cropper(image, {
                    aspectRatio: 16/9,
                    viewMode: 1,
                    autoCropArea: 0.5,
                });

                $('#cropBtn').click(function() {
                    var canvas = cropper.getCroppedCanvas();
                    canvas.toBlob(function(blob) {
                        croppedImageFile = new File([blob], "CROPPED-IMAGE-BUH.png", {type: "image/*"});
                        $('#imagePreview').html('<img src="' + URL.createObjectURL(blob) + '">');
                        $('#cropModal').removeClass('show');
                    });
                });
            };

            reader.readAsDataURL(input.files[0]);
        }
    });

    $("#submit-save").click(function() {
        $('#is_published').val(false);
    });

    $("#submit-save-public").click(function() {
      $('#is_published').val(true);
      $("#content_ifr")[0].contentWindow.unslickSliders();
    });

    $(".form_page").validate({
        rules: {
            "title_page": {
                required: true,
            },
            "short_content": {
                required: true,
            },
        },
        messages: {
            "title_page": {
                required: "Vui lòng nhập tiêu đề",
            },
            "short_content": {
                required: "Vui lòng nhập mô tả ngắn",
            },
        },
    });
    
    $('#title_page').on('keydown', function(event) {
        if (event.keyCode === 13) {
            event.preventDefault();
        }
    });
    
});


$('#url').on('input', function() {
    var snameValue = $(this).val();
    var scodeValue = removeVietnameseTones(snameValue).toLowerCase();
    $('#url').val(scodeValue);
});

function removeVietnameseTones(str) {
    str = str.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g,"a"); 
    str = str.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/g,"e"); 
    str = str.replace(/ì|í|ị|ỉ|ĩ/g,"i"); 
    str = str.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/g,"o"); 
    str = str.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/g,"u"); 
    str = str.replace(/ỳ|ý|ỵ|ỷ|ỹ/g,"y"); 
    str = str.replace(/đ/g,"d");
    str = str.replace(/À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ/g, "A");
    str = str.replace(/È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ/g, "E");
    str = str.replace(/Ì|Í|Ị|Ỉ|Ĩ/g, "I");
    str = str.replace(/Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ/g, "O");
    str = str.replace(/Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ/g, "U");
    str = str.replace(/Ỳ|Ý|Ỵ|Ỷ|Ỹ/g, "Y");
    str = str.replace(/Đ/g, "D");
    // Some system encode vietnamese combining accent as individual utf-8 characters
    // Một vài bộ encode coi các dấu mũ, dấu chữ như một kí tự riêng biệt nên thêm hai dòng này
    str = str.replace(/\u0300|\u0301|\u0303|\u0309|\u0323/g, ""); // ̀ ́ ̃ ̉ ̣  huyền, sắc, ngã, hỏi, nặng
    str = str.replace(/\u02C6|\u0306|\u031B/g, ""); // ˆ ̆ ̛  Â, Ê, Ă, Ơ, Ư
    // Remove extra spaces
    // Bỏ các khoảng trắng liền nhau
    str = str.trim().replace(/\s+/g, " ");
    // Remove punctuations
    // Bỏ dấu câu, kí tự đặc biệt
    str = str.replace(/!|@|%|\^|\*|\(|\)|\+|\=|\<|\>|\?|\/|,|\.|\:|\;|\'|\"|\&|\#|\[|\]|~|\$|_|`|-|{|}|\||\\/g," ");
    str = str.replace(/ /g, '-');
    str = str.toLowerCase();
    return str;
}
