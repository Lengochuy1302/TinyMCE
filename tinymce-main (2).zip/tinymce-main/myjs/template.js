tinymce.init({
    selector: '#template_content_add',
    plugins: 'preserve_head lists advlist anchor autolink autosave autoresize charmap code codesample directionality emoticons fullscreen help image importcss insertdatetime link lists media nonbreaking pagebreak preview quickbars save searchreplace table template visualblocks visualchars wordcount ',
    toolbar1: 'undo redo | blocks fontfamily fontsize | align lineheight | bold italic underline strikethrough forecolor backcolor | image checklist numlist bullist table mergetags | addcomment showcomments | spellcheckdialog a11ycheck typography',
    toolbar2: 'code template | link media indent outdent | emoticons charmap | removeformat',
    table_toolbar: 'tableprops tabledelete | tableinsertrowbefore tableinsertrowafter tabledeleterow | tableinsertcolbefore tableinsertcolafter tabledeletecol',
    content_style: "body { font-family: Times New Roman; }",
    autoresize_bottom_margin: 50,
    file_picker_types: 'image',
    /* and here's our custom image picker*/
    file_picker_callback: (cb, value, meta) => {
      const input = document.createElement('input');
      input.setAttribute('type', 'file');
      input.setAttribute('accept', 'image/*');
  
      input.addEventListener('change', (e) => {
        const file = e.target.files[0];
  
        const reader = new FileReader();
        reader.addEventListener('load', () => {
          /*
            Note: Now we need to register the blob in TinyMCEs image blob
            registry. In the next release this part hopefully won't be
            necessary, as we are looking to handle it internally.
          */
          const id = 'blobid' + (new Date()).getTime();
          const blobCache =  tinymce.activeEditor.editorUpload.blobCache;
          const base64 = reader.result.split(',')[1];
          const blobInfo = blobCache.create(id, file, base64);
          blobCache.add(blobInfo);
  
          /* call the callback and populate the Title field with the file name */
          cb(blobInfo.blobUri(), { title: file.name });
        });
        reader.readAsDataURL(file);
      });
  
      input.click();
    },
    automatic_uploads: false,
    relative_urls: false,
    remove_script_host: false,
    forced_root_block: true, // Ngăn TinyMCE tự thêm các thẻ mới
    verify_html: false, // Không kiểm tra mã HTML đầu vào

    cleanup_on_startup: false,
    trim_span_elements: false,
    cleanup: false,
    convert_urls: false,
    force_br_newlines: false,
    force_p_newlines: false,
    forced_root_block: '',
    valid_elements : '*[*],+*[*],head,head[*],body,body[*],meta,meta[*],title,title[*]',
    extended_valid_elements: 'head,head[*],body[*],meta[*],title[*],svg[*],rect[*],circle[*],path[*],g[*],a[*],i[*],span[class],link[href|rel],style,script[src|type],label[*]',
    custom_elements:"style,link,~link,meta,~meta,title,~title",
    templates : [
      {
        title: 'Giao diện header & footer',
        description: 'Giao diện header & footer của website',
        content: `  <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <meta name="format-detection" content="telephone=no">
        <link rel="icon" href="/buhlogoshotcut-d0c2f4f441c6c83041af8d7620f00284973f5eb63287e93a72c35d1400a743fd.png" />
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-Y8KTP274CB"></script>
        <script>
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', 'G-Y8KTP274CB');
        </script>
        <script src="/jquery.min.self-b20231c3460eaf9cd3fdf7ab2f0f77917e1ec2686590e7bdb5fb5ad69b904dd6.js?body=1"></script>
        <link rel="stylesheet" media="screen" href="/css/bootstrap.min.css" />
        <script src="/js/bootstrap.bundle.min.js"></script>
        <script src="/js/3a67e5d2e3.js"></script>
        <link rel="stylesheet" media="screen" href="/css/jquery-ui.css" />
        <script src="/js/jquery-3.6.0.js"></script>
        <link rel="stylesheet" media="screen" href="/mystyle/slick.min.css" />
        <link rel="stylesheet" media="screen" href="/mystyle/slick-theme.min.css" />
        <script src="/myjs/slick.min.js"></script>
        <script src="/js/jquery-ui.js"></script>
        <script src="/js/jquery.validate.js"></script>
        <link rel="stylesheet" media="screen" href="/application.self-5819bb9b6ffd5b06cd4b15f5ecd2377a9ae2c0159a439471332098e314127b46.css?body=1" />
        <script src="/myjs/introduc.js"></script>
        <link rel="stylesheet" media="all" href="/css/admin_icon.css" property="stylesheet" id="vc_extensions_cqbundle_adminicon-css" type="text/css" />
        <link rel="stylesheet" media="all" href="/css/trx_demo_icons.css" property="stylesheet" id="trx_demo_icons-css" type="text/css" />
        <link rel="stylesheet" media="all" href="/css/animation.css" property="stylesheet" id="trx_demo_icons_animation-css" type="text/css" />
        <link rel="stylesheet" media="all" href="/css/style.min.css" property="stylesheet" id="wp-block-library-css" type="text/css" />
        <link rel="stylesheet" media="all" href="/css/wc-blocks-vendors-style.css" property="stylesheet" id="wc-blocks-vendors-style-css" type="text/css" />
        <link rel="stylesheet" media="all" href="/css/wc-blocks-style.css" property="stylesheet" id="wc-blocks-style-css" type="text/css" />
        <link rel="stylesheet" media="all" href="/css/tooltipster.css" property="stylesheet" id="booked-tooltipster-css" type="text/css" />
        <link rel="stylesheet" media="all" href="/css/tooltipster-light.css" property="stylesheet" id="booked-tooltipster-theme-css" type="text/css" />
        <link rel="stylesheet" media="all" href="/css/animations.css" property="stylesheet" id="booked-animations-css" type="text/css" />
        <link rel="stylesheet" media="all" href="/css/booked.css" property="stylesheet" id="booked-css-css" type="text/css" />
        <link rel="stylesheet" media="all" href="/css/styles.css" property="stylesheet" id="contact-form-7-css" type="text/css" />
        <link rel="stylesheet" media="all" href="/css/settings.css" property="stylesheet" id="essential-grid-plugin-settings-css" type="text/css" />
        <link rel="stylesheet" media="all" href="/css/fontello.css" property="stylesheet" id="tp-fontello-css" type="text/css" />
        <link rel="stylesheet" media="all" href="/css/trx_addons_icons-embedded.css" property="stylesheet" id="trx_addons-icons-css" type="text/css" />
        <link rel="stylesheet" media="all" href="/css/swiper.min.css" property="stylesheet" id="swiperslider-css" type="text/css" />
        <link rel="stylesheet" media="all" href="/css/magnific-popup.min.css" property="stylesheet" id="magnific-popup-css" type="text/css" />
        <link rel="stylesheet" media="all" href="/css/trx_addons.css" property="stylesheet" id="trx_addons-css" type="text/css" />
        <link rel="stylesheet" media="all" href="/css/trx_addons.animation.css" property="stylesheet" id="trx_addons-animation-css" type="text/css" />
        <link rel="stylesheet" media="all" href="/css/trx_demo_panels.css" property="stylesheet" id="trx_demo_panels-css" type="text/css" />
        <link rel="stylesheet" media="all" href="/css/woocommerce-layout.css" property="stylesheet" id="woocommerce-layout-css" type="text/css" />
        <link rel="stylesheet" media="only screen and (max-width: 768px)" href="/css/woocommerce-smallscreen.css" property="stylesheet" id="woocommerce-smallscreen-css" type="text/css" />
        <link rel="stylesheet" media="all" href="/css/woocommerce.css" property="stylesheet" id="woocommerce-general-css" type="text/css" />
        <link rel="stylesheet" media="all" href="/css/frontend-style.css" property="stylesheet" id="booked-wc-fe-styles-css" type="text/css" />
        <link rel="stylesheet" media="all" href="/css/all.css" property="stylesheet" id="font-awesome-official-css" type="text/css" />
        <link rel="stylesheet" media="all" href="/css/js_composer.min.css" property="stylesheet" id="js_composer_front-css" type="text/css" />
        <link rel="stylesheet" media="all" href="/css/css.css" property="stylesheet" id="dental_clinic-font-google_fonts-css" type="text/css" />
        <link rel="stylesheet" media="all" href="/css/fontello-embedded.css" property="stylesheet" id="fontello-icons-css" type="text/css" />
        <link rel="stylesheet" media="all" href="/css/style.css" property="stylesheet" id="dental-clinic-main-css" type="text/css" />
        <link rel="stylesheet" media="all" href="/css/__styles.css" property="stylesheet" id="dental-clinic-styles-css" type="text/css" />
        <link rel="stylesheet" media="all" href="/css/__colors.css" property="stylesheet" id="dental-clinic-colors-css" type="text/css" />
        <link rel="stylesheet" media="all" href="/css/mediaelementplayer-legacy.min.css" property="stylesheet" id="mediaelement-css" type="text/css" />
        <link rel="stylesheet" media="all" href="/css/wp-mediaelement.min.css" property="stylesheet" id="wp-mediaelement-css" type="text/css" />
        <link rel="stylesheet" media="all" href="/css/responsive.css" property="stylesheet" id="dental-clinic-responsive-css" type="text/css" />
        <link rel="stylesheet" media="all" href="/css/v4-shims.css" property="stylesheet" id="font-awesome-official-v4shim-css" type="text/css" integrity="sha384-MAgG0MNwzSXBbmOw4KK9yjMrRaUNSCk3WoZPkzVC1rmhXzerY4gqk/BLNYtdOFCO" crossorigin="anonymous" />
        <script src="/js/jquery.min.js" id="jquery-core-js" type="text/javascript"></script>
        <script src="/js/jquery-migrate.min.js" id="jquery-migrate-js" type="text/javascript"></script>
        <script src="/js/rbtools.min.js" id="tp-tools-js" type="text/javascript"></script>
        <script src="/js/rs6.min.js" id="revmin-js" type="text/javascript"></script>
        <script src="/js/jquery.blockUI.min.js" id="jquery-blockui-js" type="text/javascript"></script>
        <script src="/js/woocommerce-add-to-cart.js" id="vc_woocommerce-add-to-cart-js-js" type="text/javascript"></script>
        <script type='text/javascript' id='booked-wc-fe-functions-js-extra'>
            var booked_wc_variables = {
                "prefix": "booked_wc_",
                "ajaxurl": "https:/-clinic.ancorathemes.com/wp-admin/admin-ajax.php",
                "i18n_confirm_appt_edit": "Are you sure you want to change the appointment date? By doing so, the appointment date will need to be approved again.",
                "i18n_pay": "Are you sure you want to add the appointment to cart and go to checkout?",
                "i18n_mark_paid": "Are you sure you want to mark this appointment as ?",
                "i18n_paid": "Paid",
                "i18n_awaiting_payment": "Awaiting Payment",
                "checkout_page": "https:/-clinic.ancorathemes.com/checkout/"
            };
        </script>
        <script src="/js/frontend-functions.js" id="booked-wc-fe-functions-js" type="text/javascript"></script>
        <script>
            $(window).on('load', function() {
                $("#loading").css("display", "none");
            });
    
            function setREVStartSize(e) {			 
                window.RSIW = window.RSIW === undefined ? window.innerWidth : window.RSIW;
                window.RSIH = window.RSIH === undefined ? window.innerHeight : window.RSIH;
                try {
                    var pw = document.getElementById(e.c).parentNode.offsetWidth, newh;
                    pw = pw === 0 || isNaN(pw) ? window.RSIW : pw;
                    e.tabw = e.tabw === undefined ? 0 : parseInt(e.tabw);
                    e.thumbw = e.thumbw === undefined ? 0 : parseInt(e.thumbw);
                    e.tabh = e.tabh === undefined ? 0 : parseInt(e.tabh);
                    e.thumbh = e.thumbh === undefined ? 0 : parseInt(e.thumbh);
                    e.tabhide = e.tabhide === undefined ? 0 : parseInt(e.tabhide);
                    e.thumbhide = e.thumbhide === undefined ? 0 : parseInt(e.thumbhide);
                    e.mh = e.mh === undefined || e.mh == "" || e.mh === "auto" ? 0 : parseInt(e.mh, 0);
                    if (e.layout === "fullscreen" || e.l === "fullscreen")
                        newh = Math.max(e.mh, window.RSIH);
                    else {
                        e.gw = Array.isArray(e.gw) ? e.gw : [e.gw];
                        for (var i in e.rl)
                            if (e.gw[i] === undefined || e.gw[i] === 0)
                                e.gw[i] = e.gw[i - 1];
                        e.gh = e.el === undefined || e.el === "" || (Array.isArray(e.el) && e.el.length == 0) ? e.gh : e.el;
                        e.gh = Array.isArray(e.gh) ? e.gh : [e.gh];
                        for (var i in e.rl)
                            if (e.gh[i] === undefined || e.gh[i] === 0)
                                e.gh[i] = e.gh[i - 1];
    
                        var nl = new Array(e.rl.length), ix = 0, sl;
                        e.tabw = e.tabhide >= pw ? 0 : e.tabw;
                        e.thumbw = e.thumbhide >= pw ? 0 : e.thumbw;
                        e.tabh = e.tabhide >= pw ? 0 : e.tabh;
                        e.thumbh = e.thumbhide >= pw ? 0 : e.thumbh;
                        for (var i in e.rl)
                            nl[i] = e.rl[i] < window.RSIW ? 0 : e.rl[i];
                        sl = nl[0];
                        for (var i in nl)
                            if (sl > nl[i] && nl[i] > 0) {
                                sl = nl[i];
                                ix = i;
                            }
                        var m = pw > (e.gw[ix] + e.tabw + e.thumbw) ? 1 : (pw - (e.tabw + e.thumbw)) / (e.gw[ix]);
                        newh = (e.gh[ix] * m) + (e.tabh + e.thumbh);
                    }
                    var el = document.getElementById(e.c);
                    if (el !== null && el)
                        el.style.height = newh + "px";
                    el = document.getElementById(e.c + "_wrapper");
                    if (el !== null && el) {
                        el.style.height = newh + "px";
                        el.style.display = "block";
                    }
                } catch (e) {
                    console.log("Failure at Presize of Slider:" + e)
                }
            };
        </script>
        
        <link rel="stylesheet" media="screen" href="/mystyle/about_us.css" />
        <link rel="stylesheet" media="screen" href="/css/flatpickr.min.css" />
        <style>
                    .vc_custom_1491233753873 {
                background-image: url('/images/bg-6.jpg') !important;
                background-position: center;
                background-repeat: no-repeat;
                background-size: cover !important;
            }
    
            .vc_custom_1490945074622 {
                background-image: url('/images/bg-3.jpg') !important;
                background-position: center;
                background-repeat: no-repeat;
                background-size: cover !important;
            }
    
            .vc_custom_1486460773205 {
                background-image: url('/images/bg-3.jpg') !important;
                background-position: center !important;
                background-repeat: no-repeat !important;
                background-size: cover !important;
            }
    
            .vc_custom_1486413163440 {
                background-image: url('/images/bg-1.png') !important;
                background-position: center !important;
                background-repeat: no-repeat !important;
                background-size: cover !important;
            }
    
            .vc_custom_1490950680332 {
                background-image: url('/images/bg-3.jpg') !important;
                background-position: center !important;
                background-repeat: no-repeat !important;
                background-size: cover !important;
            }
    
            .vc_custom_1491381388426 {
                padding-top: 5.9em !important;
                padding-bottom: 6em !important;
                background: #f7f7f7 url('/images/bg-1.png') !important;
                background-position: center !important;
                background-repeat: no-repeat !important;
                background-size: cover !important;
            }
            .vc_custom_1491297456651 {
                background: linear-gradient(to right, #02457a 45%, #018abe 65%, #97cadb 95%, #d6e7ee 120%) no-repeat scroll right bottom/210% 100% #018abe !important;
            }
            .img-post img{
                object-fit: fill !important;
            }
            .error {
                color: red !important;
            }
            input.error {
                border: 1px solid red !important;
            }
            .buh-dental-content ul li {
                list-style: unset !important;
            }
    
            ul li{
                list-style: none;
            }
    
            .nav-tag{
                height: fit-content;
            }
            .nav-tag ul li a{
                font-size: 1.15rem !important;
                font-weight: 600 !important;
            }
            .img-post{
                overflow: hidden;
                width: -webkit-fill-available;
                margin: 0 auto;
                max-width: fit-content;
            }
            .img-post img{
                transition: transform 0.25s;
                height: auto;
                width: auto;
                object-fit: fill;
            }
            .controller-posts:hover img{
                transform: scale(1.1);
            }
            .controller-posts:hover .detail_post{
                color: #37c5a6;
            }
            .calender-post, .folder-post {
                width: 13px;
                fill: #37c5a6;
            }
            .contents p{
                text-overflow: ellipsis;
                white-space: nowrap;
                overflow: hidden;
            }
            .date-tag{
                font-size: 13px;
                font-weight: 500;
                display: inline-block;
                color: #999;
                user-select: none;
            }
            @media screen and (max-width: 768px){
                .img-post img{
                    max-width: 100%;
                }
            }
            #positonjob_table_filter form{
                width: 100% !important;
            }
            li.active a{
                color: #37c5a6;
            }
            .info_dental{
                color: #000 !important;
                fill: #000;
                font-weight: 500 !important;
            }
            .info_dental:hover {
                color: #37c5a6 !important;
                fill: #37c5a6;
            }
            .loader {
                width: 100px;
                height: 100px;
                display: inline-block;
                position: relative;
            }
            .loader::after {
                content: '';
                box-sizing: border-box;
                width: 100px;
                height: 100px;
                border-radius: 50%;
                background: #54b793;
                position: absolute;
                left: 0;
                top: 0;
                opacity: 0;
                -webkit-animation: animloader 2s linear infinite;
                animation: animloader 2s linear infinite;
            }
            .loader::before {
                content: '';
                box-sizing: border-box;
                width: 100px;
                height: 100px;
                border-radius: 50%;
                background: #345ea8;
                position: absolute;
                left: 0;
                top: 0;
                opacity: 0;
                -webkit-animation: animloader 2s linear infinite;
                animation: animloader 2s linear infinite;
            }
            .loader::after {
                -webkit-animation-delay: 1s;
                animation-delay: 1s;
            }
            @keyframes animloader {
                0% {
                    transform: scale(0);
                    opacity: 1;
                }
    
                100% {
                    transform: scale(1);
                    opacity: 0;
                }
            }
            .btn.btn-success.btn-lg {
                border: 1px solid #018abe !important;
                background-color: #018abe !important;
                color: #fff !important;
            }
            .spinner {
               width: 200px; 
            }
        </style>
      </head>
      <body class="home page-template-default page page-id-2 custom-background theme-dental-clinic frontpage woocommerce-no-js body_tag scheme_default blog_mode_home body_style_wide  is_stream blog_style_excerpt sidebar_hide expand_content remove_margins header_style_header-custom-22 header_position_default menu_style_top no_layout wpb-js-composer js-comp-ver-6.9.0 vc_responsive">
        <div id="loading">
            <div class="spinner"><img src="/images/logo_web.png" width="200" alt=""></div>
            <span class="loader"></span>
        </div>
        <div class="background_body">
            <div class="image_body"><img src="/buhlogoshotcut-d0c2f4f441c6c83041af8d7620f00284973f5eb63287e93a72c35d1400a743fd.png" alt=""></div>
        </div>
        <div id="popup-social">
            <div class="social-icons">
                <a href="tel:0978647347" target="_blank" title="Hotline"><span class="sc_icon_type_fontawesome icon-phone-1" alt="hotline"></span></a>
                <a href="#" target="_blank" title="Zalo"><img src="/zalo-8838ea59d1a8aa56481e32b19c5f9985aa0ea40b39c1c0e2397349afea4791af.png" alt="zalo" width="22"></a>
                <a href="https://m.me/phauthuattaohinhthammybuh" target="_blank" title="Messenger"><img src="/messenger-dbd86b6c2238b9706b129115362f420373e4c19dbc8b4fa13a45ea35b019142f.png" alt="messenger" width="22"></a>
                <a href="/dat-lich-hen" title="Đặt lịch khám"><img src="/calendar-085fae34e1691f531d9d188bd82ff274beb6b5ac0800667086403ce88137218a.png" alt="đặt lịch khám" width="20"></a>
            </div>
        </div>
        <div class="body_wrap">
            <div class="page_wrap">
                <style> @media only screen and (max-width: 479px) { .col-6.col-sm-6.col-md-6.col-lg-3.col-xl-3.col-xxl-3 .vc_column-inner { padding-right: 10px; } } .menu_mobile_nav_area ul li a .open_child_menu { line-height: 0 !important; } .contacts_socials.socials_wrap .social_item a { display: flex; justify-content: center; align-items: center; } .scheme_default.footer_wrap a { color: #fff!important; } .textwidget#render_list_gservice p a { color: #000!important; } .textwidget#render_list_gservice p a:hover { color: #02457a!important; } </style> <header class="top_panel top_panel_custom top_panel_custom_22 without_bg_image scheme_default"> <div class="vc_row wpb_row vc_row-fluid"> <div class="wpb_column vc_column_container vc_col-sm-12 sc_layouts_column_icons_position_left"> <div class="vc_column-inner"> <div class="wpb_wrapper"> <div class="sc_layouts sc_layouts_default sc_layouts_761"> <div class="vc_row wpb_row vc_row-fluid vc_custom_1489673681815 sc_layouts_row sc_layouts_row_type_compact sc_layouts_row_delimiter"> <div class="wpb_column vc_column_container vc_col-sm-12 sc_layouts_column sc_layouts_column_align_center sc_layouts_column_icons_position_left"> <div class="vc_column-inner"> <div class="wpb_wrapper"> <div id="sc_content_1108993207" class="sc_content sc_content_default sc_float_center sc_content_width_1_1"> <div class="sc_content_container"> <div class="vc_row wpb_row vc_inner vc_row-fluid vc_row-o-equal-height vc_row-o-content-middle vc_row-flex"> <div class="wpb_column vc_column_container vc_col-sm-9 sc_layouts_column sc_layouts_column_align_left sc_layouts_column_icons_position_left"> <div class="vc_column-inner"> <div class="wpb_wrapper"> <div class="sc_layouts_item"> <div id="sc_layouts_iconed_text_1208833936" class="sc_layouts_iconed_text"><a class="sc_layouts_item_link sc_layouts_iconed_text_link" href="https://www.google.com/maps/place/B%E1%BB%87nh+vi%E1%BB%87n+%C4%90%E1%BA%A1i+h%E1%BB%8Dc+Y+D%C6%B0%E1%BB%A3c+Bu%C3%B4n+Ma+Thu%E1%BB%99t/@12.7140651,108.0709644,455m/data=!3m1!1e3!4m15!1m8!3m7!1s0x3171f78b6077fcd5:0xc8818c167f5225e!2zMjk4IEjDoCBIdXkgVOG6rXAsIFTDom4gQW4sIFRow6BuaCBwaOG7kSBCdcO0biBNYSBUaHXhu5l0LCDEkOG6r2sgTOG6r2ssIFZp4buHdCBOYW0!3b1!8m2!3d12.716205!4d108.0732047!16s%2Fg%2F11f5h462yy!3m5!1s0x3171f700689b8e7b:0xb997d666a92e8fbe!8m2!3d12.7135886!4d108.0715203!16s%2Fg%2F11jg5w5ngp"><span class="sc_layouts_item_icon sc_layouts_iconed_text_icon icon-1"></span><span class="me-3"><span class="sc_layouts_item_details_line2 sc_layouts_iconed_text_line2 info_dental">298 H&agrave; Huy Tập, Phường T&acirc;n An, TP Bu&ocirc;n Ma Thuột</span></span></a></div> </div> <div class="sc_layouts_item"> <div id="sc_layouts_iconed_text_1208833936" class="sc_layouts_iconed_text"><a href="mailto:buh@benhvienbmt.com" class="sc_layouts_item_link sc_layouts_iconed_text_link"><span class="sc_layouts_item_icon sc_layouts_iconed_text_icon icon-2"></span><span class="me-3"><span class="sc_layouts_item_details_line2 sc_layouts_iconed_text_line2"><span class="__cf_email__ info_dental" data-cfemail="2c45424a436c5543595e5f455849024f4341">buh@benhvienbmt.com</span></span></span></a></div> </div> <div class="sc_layouts_item"> <div id="sc_layouts_iconed_text_1208833936" class="sc_layouts_iconed_text"><a href="tel:0978647347" class="sc_layouts_item_link sc_layouts_iconed_text_link"><span class="sc_layouts_item_icon sc_layouts_iconed_text_icon icon-phone-1 me-1 fs-5"></span><span><span class="sc_layouts_item_details_line2 sc_layouts_iconed_text_line2"><span class="__cf_email__ info_dental" data-cfemail="2c45424a436c5543595e5f455849024f4341">0978 647 347</span></span></span></a></div> </div> </div> </div> </div> <div class="wpb_column vc_column_container vc_col-sm-3 sc_layouts_column sc_layouts_column_align_right sc_layouts_column_icons_position_left"> <div class="vc_column-inner"> <div class="wpb_wrapper"> <div class="sc_layouts_item"> <div id="sc_socials_1950036730" class="sc_socials sc_socials_default"> <div class="socials_wrap"><span class="social_item"><a href="https://www.facebook.com/phauthuattaohinhthammybuh" target="_blank" class="social_icons social_twitter" rel="noopener"><span class="trx_addons_icon-facebook info_dental "></span></a> </span><span class="social_item"><a href="#" target="_blank" class="social_icons social_facebook" rel="noopener"><span><svg class="trx_addons_icon-zalo info_dental" version="1.0" xmlns="http://www.w3.org/2000/svg" width="21" viewBox="0 0 480.000000 480.000000" preserveAspectRatio="xMidYMid meet"> <g transform="translate(0.000000,480.000000) scale(0.100000,-0.100000)"> <path d="M1255 4137 c-323 -170 -564 -453 -680 -799 -69 -208 -70 -219 -70 -938 0 -719 1 -730 70 -938 155 -461 520 -798 994 -917 168 -42 272 -47 906 -42 547 4 597 6 686 25 251 54 449 149 643 311 72 59 220 220 212 229 -2 2 -44 -17 -92 -41 -217 -109 -527 -188 -854 -218 -190 -17 -639 -6 -813 20 -176 27 -350 78 -486 141 -71 33 -121 50 -147 50 -21 0 -83 -16 -137 -35 -120 -43 -241 -65 -357 -65 -112 0 -118 10 -49 87 62 68 105 156 119 245 14 93 3 131 -71 245 -169 261 -257 511 -304 863 -9 63 -18 232 -22 375 -6 284 2 378 52 565 74 276 238 582 430 803 42 48 75 87 73 87 -2 0 -48 -24 -103 -53z"></path> <path d="M1330 2925 l0 -75 265 0 265 0 -270 -315 c-148 -173 -279 -329 -290 -347 -11 -18 -20 -45 -20 -60 l0 -28 379 0 c437 0 411 -6 411 91 l0 59 -265 0 -265 0 270 315 c148 173 279 329 290 347 11 18 20 45 20 61 l0 27 -395 0 -395 0 0 -75z"></path> <path d="M3000 2570 c0 -417 1 -431 20 -450 15 -15 33 -20 75 -20 l55 0 0 450 0 450 -75 0 -75 0 0 -430z"></path> <path d="M2380 2835 c-312 -88 -375 -499 -102 -673 109 -71 240 -77 358 -18 57 29 64 31 64 14 0 -36 36 -58 95 -58 l55 0 0 360 0 360 -75 0 c-72 0 -75 -1 -75 -23 l0 -23 -67 33 c-83 41 -171 51 -253 28z m216 -171 c145 -89 136 -307 -16 -387 -157 -82 -339 34 -328 209 11 175 195 271 344 178z"></path> <path d="M3580 2835 c-72 -21 -127 -54 -176 -107 -195 -211 -91 -545 191 -615 122 -30 246 7 340 102 115 114 143 279 73 424 -34 71 -122 154 -192 180 -79 29 -166 35 -236 16z m216 -171 c145 -89 136 -307 -16 -387 -157 -82 -339 34 -328 209 11 175 195 271 344 178z"></path> </g> </svg></span></a> </span><span class="social_item"><a href="https://www.tiktok.com/@taohinhthammybuh" target="_blank" class="social_icons social_instagram" rel="noopener"><span class="fa-brands fa-tiktok info_dental"></span></a> </span></div> </div> </div> </div> </div> </div> </div> </div> </div> </div> </div> </div> </div> <div class="vc_row wpb_row vc_row-fluid vc_custom_1489577908212 sc_layouts_row sc_layouts_row_type_compact sc_layouts_row_delimiter sc_layouts_row_fixed"> <div class="wpb_column vc_column_container vc_col-sm-12 sc_layouts_column_icons_position_left"> <div class="vc_column-inner"> <div class="wpb_wrapper"> <div id="sc_content_310173264" class="sc_content sc_content_default sc_float_center sc_content_width_1_1"> <div class="sc_content_container"> <div class="vc_row wpb_row vc_inner vc_row-fluid vc_row-o-equal-height vc_row-o-content-middle vc_row-flex"> <div class="wpb_column vc_column_container vc_col-sm-3 sc_layouts_column sc_layouts_column_align_left sc_layouts_column_icons_position_left"> <div class="vc_column-inner"> <div class="wpb_wrapper"><a href="/" id="sc_layouts_logo_1175202089" class=""><img id="logo_image" class="logo_image" src="/images/logo_web.png" alt="" width="208" height="47"></a></div> </div> </div> <div class="wpb_column vc_column_container vc_col-sm-9 sc_layouts_column sc_layouts_column_align_right sc_layouts_column_icons_position_left"> <div class="vc_column-inner"> <div class="wpb_wrapper"> <div class="sc_layouts_item"><nav id="sc_layouts_menu_655260738" class="sc_layouts_menu menu-header sc_layouts_menu_default menu_hover_fade hide_on_mobile" data-animation-in="fadeInUpSmall" data-animation-out="fadeOutDownSmall"> <ul id="menu-main-menu" class="sc_layouts_menu_nav"> <li id="menu-item-91" class="current_page_item menu-item-home menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-91"><a href="/" aria-current="page"><span>Trang chủ</span></a></li> <li id="menu-item-202" class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-202"><a href="#"><span>Giới thiệu</span></a> <ul class="sub-menu"> <li id="menu-item-124" class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-124"><a href="/ve-chung-toi"><span>Về ch&uacute;ng t&ocirc;i</span></a></li> <li id="menu-item-115" class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-115"><a href="/tin-tuc/tin-tuc-su-kien"><span>Tin tức - Sự kiện</span></a></li> <li id="menu-item-845" class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-845"><a href="/tin-tuc/kien-thuc-tham-my"><span>Kiến thức thẩm mỹ</span></a></li> </ul> </li> <li id="menu-item-105" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-105"><a href="#"><span>Dịch vụ</span></a> <ul class="buh_render_list_gservice_menu sub-menu animated fast fadeOutDownSmall" style="display: none;" id="render_list_gservice_menu">#{LIST_GSERVICE_MENU}</ul> </li> <li id="menu-item-112" class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-112"><a href="#"><span>Bảng gi&aacute; v&agrave; Ưu đ&atilde;i</span></a> <ul class="sub-menu fadeOutDownSmall animated fast" style="display: none;"> <li id="menu-item-119" class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-119"><a href="/dich-vu/bang-gia-dich-vu" class="sf-with-ul"><span>Bảng gi&aacute; dịch vụ</span></a> <ul class="sub-menu animated fast fadeOutDownSmall" style="display: none;"> <li id="menu-item-517" class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-517"><a href="/bang-gia-chi-tiet-va-chinh-sach-tra-gop"><span>Bảng gi&aacute; chi tiết v&agrave; ch&iacute;nh s&aacute;ch trả g&oacute;p</span></a></li> </ul> </li> <li id="menu-item-120" class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-120"><a href="/dich-vu/uu-dai-cho-doi-tac" class="sf-with-ul"><span>Ưu đ&atilde;i cho đối t&aacute;c</span></a></li> </ul> </li> <li id="menu-item-90" class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-90"><a href="/bac-si/doi-ngu-bac-si" aria-current="page"><span>B&aacute;c sĩ</span></a></li> <li id="menu-item-92" class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-92"><a href="/dat-lich-hen"><span>Đặt lịch hẹn</span></a></li> <li id="menu-iterow gx-0m-123" class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-123"><a href="/tin-tuc/tuyen-dung"><span>Tuyển dụng</span></a></li> </ul> </nav><span class="sc_layouts_iconed_text sc_layouts_menu_mobile_button mt-4"> <a class="sc_layouts_item_link sc_layouts_iconed_text_link social_icons social_instagram" href="#"><span class="fa-solid fa-bars fa-xl"></span></a> </span></div> <div class="sc_layouts_item sc_layouts_hide_on_tablet d-none"> <div id="sc_layouts_search_961398516" class="sc_layouts_search hide_on_tablet"> <div class="search_wrap search_style_fullscreen layouts_search"> <div class="search_form_wrap"><form class="search_form" role="search" action="https:/-clinic.ancorathemes.com/" method="get"><input class="search_field" name="s" type="text" value="" placeholder="Search"> <button class="search_submit trx_addons_icon-search" type="submit"></button> <a class="search_close trx_addons_icon-delete"></a></form></div> </div> </div> </div> </div> </div> </div> </div> </div> </div> </div> </div> </div> </div> </div> </div> </div> </div> </div> </header> <div class="menu_mobile_overlay">&nbsp;</div> <div class="menu_mobile menu_mobile_fullscreen scheme_dark"> <div class="menu_mobile_inner"><a class="menu_mobile_close icon-cancel"></a> <a class="sc_layouts_logo" href="/"><img src="/images/logo_web.png" width="100"></a><nav class="menu_mobile_nav_area"> <ul id="menu_mobile-main-menu" class=""> <li id="menu_mobile-item-91" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-91"><a href="/" aria-current="page"><span>Trang chủ</span></a></li> <li id="menu_mobile-item-202" class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-202"><a href="#"><span>Giới thiệu</span></a> <ul class="sub-menu"> <li id="menu_mobile-item-124" class=" menu-item menu-item-type-custom menu-item-124"><a href="/ve-chung-toi"><span>Về ch&uacute;ng t&ocirc;i</span></a></li> <li id="menu_mobile-item-115" class=" menu-item menu-item-type-custom menu-item-object-custom menu-item-115"><a href="/tin-tuc/tin-tuc-su-kien"><span>Tin tức - Sự kiện</span></a></li> <li id="menu_mobile-item-845" class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-845"><a href="/tin-tuc/kien-thuc-tham-my"><span>Kiến thức thẩm mỹ</span></a></li> </ul> </li> <li id="menu_mobile-item-105" class=" menu-item menu-item-type-post_type menu-item-object-custom menu-item-has-children menu-item-object-page menu-item-105"><a href="#"><span>Dịch vụ</span></a> <ul class="buh_render_list_gservice_mobile sub-menu" id="render_list_gservice_mobile">#{GSERVICE_MOBILE}</ul> </li> <li id="menu_mobile-item-112" class=" menu-item menu-item-type-post_type menu-item-has-children menu-item-object-page menu-item-112"><a href="#"><span>Bảng gi&aacute; v&agrave; Ưu đ&atilde;i</span></a> <ul class="sub-menu"> <li id="menu_mobile-item-103" class=" %&gt; menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-has-children"><a href="/dich-vu/bang-gia-dich-vu" aria-current="page"><span>Bảng gi&aacute; dịch vụ</span></a> <ul class="sub-menu"> <li id="menu_mobile-item-1110" class=" %&gt; menu-item menu-item-type-post_type menu-item-object-page menu-item-1110"><a href="/bang-gia-chi-tiet-va-chinh-sach-tra-gop"><span>Bảng gi&aacute; chi tiết v&agrave; ch&iacute;nh s&aacute;ch trả g&oacute;p</span></a></li> </ul> </li> <li id="menu_mobile-item-3870" class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-3870"><a href="/dich-vu/uu-dai-cho-doi-tac"><span>Ưu đ&atilde;i cho đối t&aacute;c</span></a></li> </ul> </li> <li id="menu_mobile-item-920" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-920"><a href="/bac-si/doi-ngu-bac-si"><span>B&aacute;c sĩ</span></a></li> <li id="menu_mobile-item-123" class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-123"><a href="/dat-lich-hen"><span>Đặt lịch hẹn</span></a></li> <li id="menu_mobile-item-99" class=" menu-item menu-item-type-post_type menu-item-object-page menu-item-99"><a href="/tin-tuc/tuyen-dung"><span>Tuyển dụng</span></a></li> </ul> </nav> <div class="socials_mobile"><span class="social_item"><a href="https://www.facebook.com/phauthuattaohinhthammybuh" target="_blank" style="background: none !important;" class="social_icons social_twitter" rel="noopener"><span class="trx_addons_icon-facebook"></span></a> </span><span class="social_item"><a href="#" target="_blank" style="background: none !important;" class="social_icons social_facebook" rel="noopener"><span><svg class="trx_addons_icon-zalo_mobile" version="1.0" xmlns="http://www.w3.org/2000/svg" width="21" viewBox="0 0 480.000000 480.000000" preserveAspectRatio="xMidYMid meet"> <g transform="translate(0.000000,480.000000) scale(0.100000,-0.100000)"> <path d="M1255 4137 c-323 -170 -564 -453 -680 -799 -69 -208 -70 -219 -70 -938 0 -719 1 -730 70 -938 155 -461 520 -798 994 -917 168 -42 272 -47 906 -42 547 4 597 6 686 25 251 54 449 149 643 311 72 59 220 220 212 229 -2 2 -44 -17 -92 -41 -217 -109 -527 -188 -854 -218 -190 -17 -639 -6 -813 20 -176 27 -350 78 -486 141 -71 33 -121 50 -147 50 -21 0 -83 -16 -137 -35 -120 -43 -241 -65 -357 -65 -112 0 -118 10 -49 87 62 68 105 156 119 245 14 93 3 131 -71 245 -169 261 -257 511 -304 863 -9 63 -18 232 -22 375 -6 284 2 378 52 565 74 276 238 582 430 803 42 48 75 87 73 87 -2 0 -48 -24 -103 -53z"></path> <path d="M1330 2925 l0 -75 265 0 265 0 -270 -315 c-148 -173 -279 -329 -290 -347 -11 -18 -20 -45 -20 -60 l0 -28 379 0 c437 0 411 -6 411 91 l0 59 -265 0 -265 0 270 315 c148 173 279 329 290 347 11 18 20 45 20 61 l0 27 -395 0 -395 0 0 -75z"></path> <path d="M3000 2570 c0 -417 1 -431 20 -450 15 -15 33 -20 75 -20 l55 0 0 450 0 450 -75 0 -75 0 0 -430z"></path> <path d="M2380 2835 c-312 -88 -375 -499 -102 -673 109 -71 240 -77 358 -18 57 29 64 31 64 14 0 -36 36 -58 95 -58 l55 0 0 360 0 360 -75 0 c-72 0 -75 -1 -75 -23 l0 -23 -67 33 c-83 41 -171 51 -253 28z m216 -171 c145 -89 136 -307 -16 -387 -157 -82 -339 34 -328 209 11 175 195 271 344 178z"></path> <path d="M3580 2835 c-72 -21 -127 -54 -176 -107 -195 -211 -91 -545 191 -615 122 -30 246 7 340 102 115 114 143 279 73 424 -34 71 -122 154 -192 180 -79 29 -166 35 -236 16z m216 -171 c145 -89 136 -307 -16 -387 -157 -82 -339 34 -328 209 11 175 195 271 344 178z"></path> </g> </svg></span></a> </span><span class="social_item"><a href="#" target="_blank" style="background: none !important;" class="social_icons social_instagram ms-2" rel="noopener"><span class="fa-brands fa-tiktok"></span></a> </span></div> </div> </div> <div id="render_content_pages" class="buh_render_content_pages">#{CONTENT}</div> <footer class="footer_wrap footer_custom footer_custom_11 scheme_default"> <div class="vc_row wpb_row vc_row-fluid vc_custom_1486566842909 vc_row-has-fill sc_layouts_row sc_layouts_row_type_normal p-0 m-0"> <div class="wpb_column vc_column_container vc_col-sm-12 sc_layouts_column_icons_position_left" style="box-shadow: rgba(0, 0, 0, 0.1) 0px 0px 6px -1px, rgba(0, 0, 0, 0.06) 0px -4px 4px -1px; ; padding-top: 100px; background: #fff;"> <div class="vc_column-inner"> <div class="wpb_wrapper"> <div id="sc_content_1669203341" class="sc_content sc_content_default sc_float_center sc_content_width_1_1"> <div class="sc_content_container"> <div class="row gx-0"> <div class="col-12 col-sm-6 col-md-6 col-lg-3 col-xl-3 col-xxl-3"> <div class="vc_column-inner"> <div class="wpb_wrapper"> <div class="vc_wp_text wpb_content_element"> <div class="widget widget_text"> <div class="vc_column-inner"> <div class="wpb_wrapper"> <div class="sc_layouts_item"><a href="/" id="sc_layouts_logo_1175202089" class=""><img class="logo_image" src="/images/logo_web.png" alt="" width="200"></a></div> </div> </div> </div> <div class="vc_wp_text wpb_content_element"> <div class="widget widget_text mt-4 mb-5"> <h2 class="widgettitle"><span>Dịch vụ</span></h2> <div class="buh_render_list_gservice textwidget" id="render_list_gservice"><span>#{LIST_GSERVICE}</span></div> </div> </div> </div> </div> </div> </div> <div class="col-12 col-sm-6 col-md-6 col-lg-5 col-xl-5 col-xxl-4 mb-4"> <div class="vc_column-inner"> <div class="wpb_wrapper"> <div class="vc_wp_text wpb_content_element"> <div class="widget widget_text mb-4"> <h2 class="widgettitle m-0"><span>Giờ kh&aacute;m bệnh:</span></h2> <div class="textwidget mt-1"> <p style="cursor: pointer;"><span><a style="color: #000 !important;">Thứ Hai &ndash; Chủ Nhật (07h30 - 16h00)</a></span></p> </div> </div> </div> <div class="vc_wp_text wpb_content_element"> <div class="widget widget_text mb-4"> <h2 class="widgettitle m-0"><span>Cấp cứu:</span></h2> <div class="textwidget mt-1"> <p style="cursor: pointer;"><span><a style="color: #000 !important;">24/7 (Hotline 1900 1147 &ndash; Nhấm ph&iacute;m 1)</a></span></p> </div> </div> </div> <div class="vc_wp_text wpb_content_element"> <div class="widget widget_text mb-4"> <h2 class="widgettitle m-0"><span>Hotline:</span></h2> <div class="textwidget mt-1"> <p style="cursor: pointer;"><span><a style="color: #000 !important;">0978 647 347 (Tổng đ&agrave;i hỗ trợ trong giờ h&agrave;nh ch&iacute;nh)</a></span></p> </div> </div> </div> <div class="vc_wp_text wpb_content_element"> <div class="widget widget_text mb-4"> <h2 class="widgettitle m-0"><span>Địa chỉ:</span></h2> <div class="textwidget mt-1"> <p style="cursor: pointer;"><span><a style="color: #000 !important;">298 H&agrave; Huy Tập, T&acirc;n An, TP. Bu&ocirc;n Ma Thuột, Đắk Lắk</a></span></p> </div> </div> </div> </div> </div> </div> <div class="col-12 col-sm-12 col-md-11 col-lg-4 col-xl-4 col-xxl-5"> <div class="vc_column-inner"> <div class="wpb_wrapper"> <div class="vc_wp_text wpb_content_element"> <div class="widget widget_text"> <h2 class="widgettitle"><span>Đăng k&yacute; nhận tin</span></h2> <div class="textwidget mt-1"><form id="mc4wp-form-1" class="mc4wp-form mc4wp-form-496" method="post" data-id="496" data-name="Form1"> <div class="mc4wp-form-fields"><span><input class="input-email mb-3" autocomplete="off" name="EMAIL" required="" type="email" placeholder="Nhập email của bạn"> <button class="fa-solid fa-paper-plane" type="submit"></button></span></div> <span><label style="display: none !important;">Leave this field empty if you're human: <input autocomplete="off" name="_mc4wp_honeypot" type="text" value="" tabindex="-1"></label> <input name="_mc4wp_timestamp" type="hidden" value="1678068474"><input name="_mc4wp_form_id" type="hidden" value="496"><input name="_mc4wp_form_element_id" type="hidden" value="mc4wp-form-1"></span> <div class="mc4wp-response"><span>&nbsp;</span></div> </form></div> </div> </div> <div class="sc_layouts_item"> <div id="widget_contacts_706644808" class="widget_area sc_widget_contacts vc_widget_contacts wpb_content_element"> <aside id="widget_contacts_706644808_widget" class="widget widget_contacts"> <h2 class="widgettitle"><span>Follow us</span></h2> <div class="contacts_wrap"> <div class="contacts_socials socials_wrap"><span class="social_item"><span><a href="https://www.tiktok.com/@taohinhthammybuh" target="_blank" class="social_icons social_twitter" rel="noopener" style="color: rgb(0, 0, 0);"><span class="fa-brands fa-tiktok"></span></a></span> </span><span class="social_item"><a href="https://www.facebook.com/phauthuattaohinhthammybuh" target="_blank" class="social_icons social_facebook" rel="noopener"><span class="trx_addons_icon-facebook"></span></a> </span><span class="social_item"><a href="#" target="_blank" class="social_icons social_instagram" rel="noopener"><span><svg class="trx_addons_icon-zalo-light" style="fill: #fff;" version="1.0" xmlns="http://www.w3.org/2000/svg" width="21" viewBox="0 0 480.000000 480.000000" preserveAspectRatio="xMidYMid meet"> <g transform="translate(0.000000,480.000000) scale(0.100000,-0.100000)"> <path d="M1255 4137 c-323 -170 -564 -453 -680 -799 -69 -208 -70 -219 -70 -938 0 -719 1 -730 70 -938 155 -461 520 -798 994 -917 168 -42 272 -47 906 -42 547 4 597 6 686 25 251 54 449 149 643 311 72 59 220 220 212 229 -2 2 -44 -17 -92 -41 -217 -109 -527 -188 -854 -218 -190 -17 -639 -6 -813 20 -176 27 -350 78 -486 141 -71 33 -121 50 -147 50 -21 0 -83 -16 -137 -35 -120 -43 -241 -65 -357 -65 -112 0 -118 10 -49 87 62 68 105 156 119 245 14 93 3 131 -71 245 -169 261 -257 511 -304 863 -9 63 -18 232 -22 375 -6 284 2 378 52 565 74 276 238 582 430 803 42 48 75 87 73 87 -2 0 -48 -24 -103 -53z"></path> <path d="M1330 2925 l0 -75 265 0 265 0 -270 -315 c-148 -173 -279 -329 -290 -347 -11 -18 -20 -45 -20 -60 l0 -28 379 0 c437 0 411 -6 411 91 l0 59 -265 0 -265 0 270 315 c148 173 279 329 290 347 11 18 20 45 20 61 l0 27 -395 0 -395 0 0 -75z"></path> <path d="M3000 2570 c0 -417 1 -431 20 -450 15 -15 33 -20 75 -20 l55 0 0 450 0 450 -75 0 -75 0 0 -430z"></path> <path d="M2380 2835 c-312 -88 -375 -499 -102 -673 109 -71 240 -77 358 -18 57 29 64 31 64 14 0 -36 36 -58 95 -58 l55 0 0 360 0 360 -75 0 c-72 0 -75 -1 -75 -23 l0 -23 -67 33 c-83 41 -171 51 -253 28z m216 -171 c145 -89 136 -307 -16 -387 -157 -82 -339 34 -328 209 11 175 195 271 344 178z"></path> <path d="M3580 2835 c-72 -21 -127 -54 -176 -107 -195 -211 -91 -545 191 -615 122 -30 246 7 340 102 115 114 143 279 73 424 -34 71 -122 154 -192 180 -79 29 -166 35 -236 16z m216 -171 c145 -89 136 -307 -16 -387 -157 -82 -339 34 -328 209 11 175 195 271 344 178z"></path> </g> </svg></span></a> </span></div> </div> </aside> </div> </div> </div> </div> </div> </div> </div> </div> </div> </div> </div> </div> </footer>
    
    
    
            </div>
        </div>
        <script>
            const url_calendar = "/calendar-085fae34e1691f531d9d188bd82ff274beb6b5ac0800667086403ce88137218a.png";
        </script>
        <script src="/myjs/home_index.js"></script>
        <script src="/myjs/appointment.js"></script>
        <script type="text/javascript">
    window.onload = function () {
            $("#popup").css('display','block');
            $('.btnclose').on('click', function() {
               $("#popup").css('display','none');
            });
    }
            if (typeof revslider_showDoubleJqueryError === "undefined") {
                function revslider_showDoubleJqueryError(sliderID) {
                    console.log("You have some jquery.js library include that comes after the Slider Revolution files js inclusion.");
                    console.log("To fix this, you can:");
                    console.log("1. Set 'Module General Options' -> 'Advanced' -> 'jQuery & OutPut Filters' -> 'Put JS to Body' to on");
                    console.log("2. Find the double jQuery.js inclusion and remove it");
                    return "Double Included jQuery Library";
                }
            }
        </script>
        <link rel="stylesheet" media="all" href="/css/v4-shims.min.css" property="stylesheet" id="vc_font_awesome_5_shims-css" type="text/css" />
        <link rel="stylesheet" media="all" href="/css/all.min.css" property="stylesheet" id="vc_font_awesome_5-css" type="text/css" />
        <link rel="stylesheet" media="all" href="/css/style_957.css" property="stylesheet" id="vc-extensions-flipbox-style-css" type="text/css" />
        <link rel="stylesheet" media="all" href="/css/rs6.css" property="stylesheet" id="rs-plugin-settings-css" type="text/css" />
        <script src="/js/core.min.js" id="jquery-ui-core-js" type="text/javascript"></script>
        <script src="/js/datepicker.min.js" id="jquery-ui-datepicker-js" type="text/javascript"></script>
        <script src="/js/spin.min.js" id="booked-spin-js-js" type="text/javascript"></script>
        <script src="/js/spin.jquery.js" id="booked-spin-jquery-js" type="text/javascript"></script>
        <script src="/js/jquery.tooltipster.min.js" id="booked-tooltipster-js" type="text/javascript"></script>
        <script src="/js/functions.js" id="booked-functions-js" type="text/javascript"></script>
        <script src="/js/index.js" id="swv-js" type="text/javascript"></script>
        <script src="/js/index_1012.js" id="contact-form-7-js" type="text/javascript"></script>
        <script src="/js/swiper.jquery.min.js" id="swiperslider-js" type="text/javascript"></script>
        <script src="/js/jquery.magnific-popup.min.js" id="magnific-popup-js" type="text/javascript"></script>
        <script type='text/javascript'>
            var TRX_ADDONS_STORAGE = {
            };
            var TRX_DEMO_STORAGE  = {
            };
            var wpcf7 = {"api":{"root":"https:/-clinic.ancorathemes.com/wp-json/","namespace":"contact-form-7/v1"}};
        </script>
        <script src="/js/trx_addons.js" id="trx_addons-js" type="text/javascript"></script>
        <script src="/js/trx_demo_panels.js" id="trx_demo_panels-js" type="text/javascript"></script>
        <script src="/js/js.cookie.min.js" id="js-cookie-js" type="text/javascript"></script>
        <script src="/js/woocommerce.min.js" id="woocommerce-js" type="text/javascript"></script>
        <script src="/js/cart-fragments.min.js" id="wc-cart-fragments-js" type="text/javascript"></script>
        <script src="/js/functions_1105.js" id="booked-fea-js-js" type="text/javascript"></script>
        <script src="/js/superfish.js" id="superfish-js" type="text/javascript"></script>
        <script src="/js/__scripts.js" id="dental-clinic-ini-js" type="text/javascript"></script>
        <script src="/js/mediaelement-and-player.min.js" id="mediaelement-core-js" type="text/javascript"></script>
        <script src="/js/mediaelement-migrate.min.js" id="mediaelement-migrate-js" type="text/javascript"></script>
        <script src="/js/wp-mediaelement.min.js" id="wp-mediaelement-js" type="text/javascript"></script>
        <script type='text/javascript' id='wpb_composer_front_js-js-extra'>
            var vcData = {
                "currentTheme": {
                    "slug": "dental-clinic"
                }
            };
        </script>
        <script src="/js/js_composer_front.min.js" id="wpb_composer_front_js-js" type="text/javascript"></script>
        <script src="/js/skrollr.min.js" id="vc_jquery_skrollr_js-js" type="text/javascript"></script>
        <script src="/js/vc-waypoints.min.js" id="vc_waypoints-js" type="text/javascript"></script>
        <script src="/js/init.min.js" id="vc-extensions-flipbox-script-js" type="text/javascript"></script>
        <script src="/js/forms.js" id="mc4wp-forms-api-js" type="text/javascript"></script>
        <script type="text/javascript" id="rs-initialisation-scripts">
            var tpj = jQuery;
    
            var revapi1;
    
            if (window.RS_MODULES === undefined)
                window.RS_MODULES = {};
            if (RS_MODULES.modules === undefined)
                RS_MODULES.modules = {};
            RS_MODULES.modules["revslider11"] = {
                once: RS_MODULES.modules["revslider11"] !== undefined ? RS_MODULES.modules["revslider11"].once : undefined,
                init: function() {
                    window.revapi1 = window.revapi1 === undefined || window.revapi1 === null || window.revapi1.length === 0 ? document.getElementById("rev_slider_1_1") : window.revapi1;
                    if (window.revapi1 === null || window.revapi1 === undefined || window.revapi1.length == 0) {
                        window.revapi1initTry = window.revapi1initTry === undefined ? 0 : window.revapi1initTry + 1;
                        if (window.revapi1initTry < 20)
                            requestAnimationFrame(function() {
                                RS_MODULES.modules["revslider11"].init()
                            });
                        return;
                    }
                    window.revapi1 = jQuery(window.revapi1);
                    if (window.revapi1.revolution == undefined) {
                        revslider_showDoubleJqueryError("rev_slider_1_1");
                        return;
                    }
                    revapi1.revolutionInit({
                        revapi: "revapi1",
                        DPR: "dpr",
                        sliderLayout: "fullwidth",
                        visibilityLevels: "1240,1024,778,480",
                        gridwidth: 1170,
                        gridheight: 606,
                        startDelay: "0ms",
                        lazyType: "smart",
                        spinner: "spinner0",
                        perspective: 600,
                        perspectiveType: "local",
                        editorheight: "606,768,960,720",
                        responsiveLevels: "1240,1024,778,480",
                        progressBar: {
                            disableProgressBar: true
                        },
                        navigation: {
                            mouseScrollNavigation: false,
                            wheelCallDelay: 1000,
                            onHoverStop: false,
                            touch: {
                                touchenabled: true,
                                touchOnDesktop: true
                            }
                        },
                        fallbacks: {
                            allowHTML5AutoPlayOnAndroid: true
                        },
                    });
    
                }
            }
            if (window.RS_MODULES.checkMinimal !== undefined) {
                window.RS_MODULES.checkMinimal();
            }
        </script>
        <a href="#" class="trx_addons_scroll_to_top trx_addons_icon-up" title="Lên đầu trang"></a>
        <script src="/js/flatpickr.js"></script>
        <script src="/js/jquery_ujs.js"></script>
      </body>`
      },
    ],
    custom_formats: [
      {
        name: 'fontawesome',
        inline: 'span',
        classes: 'fa'
      }
    ],
    setup: function (editor) {

        editor.ui.registry.addButton('fontawesome', {
          icon: 'fas fa-heart',
          tooltip: 'Insert Heart Icon',
          onAction: function() {
              editor.insertContent('<i class="fas fa-heart"></i>');
          }
      });
      editor.ui.registry.addButton('fontawesome', {
        icon: 'fas fa-smile',
        tooltip: 'Insert Font Awesome Icon',
        onAction: function () {
          editor.insertContent('<i class="fas fa-smile"></i>');
        }
      });
    },
    resize: true,
    min_height: 400,
    content_css_cors: true,
    content_js_cors: true,
    content_scripts: [
        { src: '/myjs/jquery.min.js' },
        { src: '/myjs/tinymce.min.js' }
      ],
    content_css: [
        '/css/bootstrap.min.css',
        '/css/jquery-ui.css',
        '/mystyle/slick.min.css',
        '/mystyle/slick-theme.min.css',
        '/application.css',
        '/css/admin_icon.css',
        '/css/trx_demo_icons.css',
        '/css/animation.css',
        '/css/style.min.css',
        '/css/wc-blocks-vendors-style.css',
        '/css/wc-blocks-style.css',
        '/css/tooltipster.css',
        '/css/tooltipster-light.css',
        '/css/animations.css',
        '/css/booked.css',
        '/css/styles.css',
        '/css/settings.css',
        '/css/fontello.css',
        '/css/trx_addons_icons-embedded.css',
        '/css/swiper.min.css',
        '/css/magnific-popup.min.css',
        '/css/trx_addons.css',
        '/css/trx_addons.animation.css',
        '/css/trx_demo_panels.css',
        '/css/woocommerce-layout.css',
        '/css/woocommerce-smallscreen.css',
        '/css/woocommerce.css',
        '/css/frontend-style.css',
        '/css/all.css',
        '/css/js_composer.min.css',
        '/css/css.css',
        '/css/fontello-embedded.css',
        '/css/style.css',
        '/css/__styles.css',
        '/css/__colors.css',
        '/css/mediaelementplayer-legacy.min.css',
        '/css/wp-mediaelement.min.css',
        '/css/responsive.css',
        '/css/v4-shims.css',
        '/css/all.min.css',
        '/css/css_935.css',
        '/css/dataTables-bootstrap5.min.css',
        '/css/flatpickr.min.css',
        '/css/rs6.css',
        '/css/style_957.css',
        '/css/v4-shims.min.css',
        '/mystyle/application.css',
        '/mystyle/appointment.css',
        '/mystyle/choices.min.css',
        '/mystyle/cropper.min.css',
        '/mystyle/home_index.css',
        '/mystyle/slick-theme.min.css',
        '/mystyle/slick.min.css',
        '/application.css.scss',
        '/daterangepicker.css',
        '/dropzone.min.css',
        '/jquery-ui.css',
        '/prism-okaidia.css',
        '/sessions.scss',
        '/simplebar.min.css',
        '/user-rtl.min.css',
        '/user.min.css',
        '/css/all.min_bt.css',
    ],

    importcss_append: true,
    color_map: [
        '#BFEDD2', 'Light Green',
        '#FBEEB8', 'Light Yellow',
        '#F8CAC6', 'Light Red',
        '#ECCAFA', 'Light Purple',
        '#C2E0F4', 'Light Blue',
      
        '#2DC26B', 'Green',
        '#F1C40F', 'Yellow',
        '#E03E2D', 'Red',
        '#B96AD9', 'Purple',
        '#3598DB', 'Blue',
      
        '#169179', 'Dark Turquoise',
        '#E67E23', 'Orange',
        '#BA372A', 'Dark Red',
        '#843FA1', 'Dark Purple',
        '#236FA1', 'Dark Blue',
      
        '#ECF0F1', 'Light Gray',
        '#CED4D9', 'Medium Gray',
        '#95A5A6', 'Gray',
        '#7E8C8D', 'Dark Gray',
        '#34495E', 'Navy Blue',
      
        '#000000', 'Black',
        '#ffffff', 'White'
      ]
});


function delete_loading_template(element){
    element.style.display = "none"
    element.previousElementSibling.style.display = "none"
    element.nextElementSibling.style.display = "block"
  }



function openFormAddTemplate() {
    document.getElementById("form-add-template-container").style.display = "block";
    document.getElementById("cls_bmtu_form_add_title").innerHTML = createtemplate;
    document.getElementById("btn_add_new_template_buttton").value = btn_create;
    document.getElementById("template_id_add").value = "";
    document.getElementById("template_title_add").value = "";

}
function openFormUpdateTemplate() {
  document.getElementById("form-add-template-container").style.display = "block";
}
function closeFormAddTemplate() {
    document.getElementById("form-add-template-container").style.display = "none";
    document.getElementById("template_id_add").value = "";
    document.getElementById("template_title_add").value = "";
    document.getElementById("template_content_addd").value = "";   
    document.getElementById("template_title_add").style.border = "1px solid #ced4da";
    document.getElementById('erro_labble_content').style.display = "none";
      
}
$('#btn_add_new_template_buttton').click(function (){
    var title = $('#template_title_add').val();
    if (title=="") {
        $('#template_title_add').attr('style',' border: 1px solid red !important');
        $('#erro_labble_content').html('Bạn hãy nhập title');
        $('#erro_labble_content').css('display', 'block');

    } else {
        $('#template_title_add').attr('style','border: 1px solid #ddd !important');
        $('#erro_labble_content').html('')
        $('#erro_labble_content').css('display', 'none');
        $('#form_add_template').submit();
    }
});

$('#template_title_add').change(function (){
    var title = $('#template_title_add').val();
    if (title=="") {
        $('#template_title_add').attr('style','border:1px solid red 1important');
        $('#erro_labble_content').html('Bạn hãy nhập title');
        $('#erro_labble_content').css('display', 'block');

    } else {
        $('#template_title_add').attr('style',' border: 1px solid #ddd !important');
        $('#erro_labble_content').html('')
        $('#erro_labble_content').css('display', 'none');
    }
})

$('.modal').on('show.bs.modal', function () {
    $('#template_title_add').val('');
    $('#erro_labble_content').html('')
    $('#erro_labble_content').css('display', 'none');
})
$('#myModal').on('shown.bs.modal', function () {
    $('#myInput').trigger('focus')
})
    $("#getCameraSerialNumbers").click(function () {
});
function insertFontAwesomeIcon(iconClass) {
    tinymce.activeEditor.insertContent('<span class="' + iconClass + '"></span>');
  }

  tinymce.PluginManager.add('preserve_head', function(editor) {
    // Hàm xử lý trước khi lưu nội dung
    function onBeforeSetContent(e) {
      // Kiểm tra nếu chế độ mã nguồn được kích hoạt
      if (editor.mode.get() === 'source') {
        // Tìm thẻ <head> trong nội dung
        var headStartIndex = e.content.indexOf('<head>');
        var headEndIndex = e.content.indexOf('</head>');
        if (headStartIndex > -1 && headEndIndex > -1) {
          // Lấy nội dung bên trong thẻ <head>
          var headContent = e.content.substring(headStartIndex + 6, headEndIndex);
  
          // Thay thế thẻ <head> bằng một thẻ tạm thời
          var tempHead = '<div id="temp_head" style="display:none;"></div>';
          e.content = e.content.replace(/<head>[\s\S]*<\/head>/i, tempHead);
  
          // Chèn lại nội dung của thẻ <head> vào trước nội dung
          e.content = headContent + e.content;
        }
      }
    }
  
    // Đăng ký sự kiện
    editor.on('BeforeSetContent', onBeforeSetContent);
  });