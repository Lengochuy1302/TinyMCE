$(document).ready(function(){
      // thêm các slide vào container
      $('#slider_top_web').slick({
        dots: false, 
        arrows: false,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        infinite: true, 
        speed: 1000, 
        fade: true,
        cssEase: 'linear',
        adaptiveHeight: true,
      });
    // thêm các slide vào container
    $('#slider_services').slick({
      dots: false, 
      arrows: false,
      slidesToShow: 3,
      slidesToScroll: 2,
      autoplay: true,
      autoplaySpeed: 2000,
      infinite: true, 
      speed: 500, 
      responsive: [ 
        {
          breakpoint: 1024, 
          settings: {
            slidesToShow: 2, 
            slidesToScroll: 1
          }
        },
        {
          breakpoint: 768, 
          settings: {
            slidesToShow: 1, 
            slidesToScroll: 1 
          }
        }
      ]
    });
    $('.slider_sale').slick({
      dots: false, 
      arrows: false,
      slidesToShow: 5,
      slidesToScroll: 2,
      autoplay: true,
      autoplaySpeed: 2000,
      infinite: true, 
      speed: 500, 
      responsive: [ 
        {
          breakpoint: 1024, 
          settings: {
            slidesToShow: 4, 
            slidesToScroll: 1
          }
        },
        {
          breakpoint: 768, 
          settings: {
            slidesToShow: 3, 
            slidesToScroll: 1 
          }
        },
        {
          breakpoint: 426, 
          settings: {
            slidesToShow: 2, 
            slidesToScroll: 1 
          }
        }
      ]
    });
    // thêm các slide vào container
    $('#slider_doctor').slick({
      dots: false, 
      arrows: false,
      slidesToShow: 2,
      slidesToScroll: 1,
      autoplay: true,
      autoplaySpeed: 2000,
      infinite: true, 
      speed: 500, 
      variableWidth: true,
      responsive: [ 
        {
          breakpoint: 1024, 
          settings: {
            slidesToShow: 2, 
            slidesToScroll: 1
          }
        },
        {
          breakpoint: 768, 
          settings: {
            slidesToShow: 1, 
            slidesToScroll: 1 
          }
        }
      ]
    });
// 
    $("#form_booking").validate({
      rules: {
        "number_phone": {
          required: true,
        },
        "last_name": {
          required: true,
        },
        "first_name": {
          required: true,
        },
      },
      messages: {
        "number_phone": {
          required: "Bắt buộc nhập số điện thoại",
        },
        "last_name": {
          required: "Bắt buộc nhập họ",
        },
        "first_name": {
          required: "Bắt buộc nhập tên",
        },
      },
    });
    $("#btn_order").click(function() {     

      $("#form_booking").submit()
      var stypleErrror = $('.error').parent();
      stypleErrror.css({
       "text-align":"left"
      })

    });
  });

const popup = document.getElementById('popup');
const close = document.querySelector('.btnclose');

window.onload = function () {
  if (popup) {
    popup.style.display = 'block';
  }
}
if (close) {
  close.onclick = function () {
      popup.style.display = 'none';
  }
}

$( function() {
        $( "#datepicker" ).datepicker();
} );

var now = new Date();
var hours = now.getHours().toString().padStart(2, '0');
var minutes = now.getMinutes().toString().padStart(2, '0');
var timeString = hours + ':' + minutes; 
var dateString = now.getDate().toString().padStart(2, '0') + '/' + (now.getMonth() + 1).toString().padStart(2, '0') + '/' + now.getFullYear().toString().padStart(4, '0');
$('#timepicker').val(timeString)
$('#datepicker').val(dateString)

 // datepicker
$( ".datepicker" ).datepicker({
showButtonPanel: true,
dateFormat: "dd/mm/yy",
changeMonth: true,
changeYear: true,
yearRange: "c-100:c+10",
dayNamesMin : [ "S", "M", "T", "W", "T", "F", "S" ],
// defaultDate: +1,
buttonImage: url_calendar,
buttonImageOnly: true,
showOn: "button",
buttonText: 'Choose_date',
closeText: 'closeText',
prevText: 'prevText',
nextText: 'nextText',
currentText: 'Hôm nay',
monthNamesShort: ['Tháng 1', 'Tháng 2', 'Tháng 3', 'Tháng 4',
'Tháng 5', 'Tháng 6', 'Tháng 7', 'Tháng 8',
'Tháng 9', 'Tháng 10', 'Tháng 11', 'Tháng 12'],
dayNamesMin: ['CN', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7'],
firstDay: 1,
isRTL: false,
showMonthAfterYear: false,
yearSuffix: "",
});
