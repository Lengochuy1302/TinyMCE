$(function() {
    var start = moment().startOf('week');
    var end = moment().endOf('week');

    function cb(start, end) {
        $('#range_order_search span').html(start.format('DD/MM/YYYY') + ' - ' + end.format('DD/MM/YYYY'));
    }

    function setInputDate(start,end){

        $("#form-search-order").find('input[name="from"]').val(start);
        $("#form-search-order").find('input[name="to"]').val(end);
        // export form
        let form = $($("#form_export_order")[0]);
        form.find('[name="from"]').val(start);
        form.find('[name="to"]').val(end);

    }

    $('#range_order_search').daterangepicker({
        locale: {
            cancelLabel: 'Đóng',
            applyLabel: 'Áp dụng',
            customRangeLabel: "Tùy chỉnh",
            monthNames:["Tháng 1","Tháng 2","Tháng 3","Tháng 4","Tháng 5" ,"Tháng 6","Tháng 7","Tháng 8","Tháng 9","Tháng 10","Tháng 11","Tháng 12"],
            daysOfWeek:["Hai","Ba","Tư","Năm","Sáu","Bảy","CN"]
        },
        startDate: start,
        endDate: end,
        ranges: {
           'Hôm nay': [moment(), moment()],
           'Hôm qua': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
           'Tuần này':[moment().startOf('week'),moment().endOf('week')],
           '7 ngày trước': [moment().subtract(6, 'days'), moment()],
           '7 ngày tới':[moment(), moment().add(6, 'days')],
           '30 ngày trước': [moment().subtract(29, 'days'), moment()],
           '30 ngày tới': [moment(),moment().add(29, 'days')],
           'Tháng này': [moment().startOf('month'), moment().endOf('month')],
           'Tháng trước': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        }
    }, cb);
    setInputDate(start.format('YYYY-MM-DD'),end.format('YYYY-MM-DD'));
    cb(start, end);

    // event
    $('#range_order_search').on('apply.daterangepicker', function(ev, picker) {
        let start = picker.startDate;
        let end = picker.endDate;
        let s_start = moment(start._d).format("YYYY-MM-DD");
        let s_end = moment(end._d).format("YYYY-MM-DD");
        setInputDate(s_start,s_end);
    });
})

function Choses_type(type) {
    $("#type_confirm").val(type);
    $("#type_confirm_appointment").val(type);
}
function Choses_type_booking(type) {
    $("#type_confirm_appointment").val(type);
    $('#form_confirm_user_booking').submit();
}

function Open_confirm_modal(id, content){
    $("#id_order_confirm").val(id);
    $("#note_confirm").val("");
    $('#collapseExample').removeClass('show');
    $("input[id='2']").prop('checked',true);
    $("select[name='service_order']").prop("selectedIndex", 0).val();
    $("#date_order_adv").val(time_now);
    // $("#date_order_appointment").val(time_now);
}

function Open_confirm_modal1(id, full_name,phone, date_time){
    $("#id_order").val(id);
    $("#name_order_appointment").text(full_name);
    $("#phone_order_appointment").text(phone);
    $("#date_order_appointment").val(date_time);
    console.log(date_time);
}

function Open_confirm_modal2(id, full_name,phone,date_time){
    $("#id_order1").val(id);
    $("#name_order_appointment1").text(full_name);
    $("#phone_order_appointment1").text(phone);
    $("#note").val("");
    $("#date_order_appointment2").val(date_time);
    $("input[id='dat-lich-2']").prop('checked',true);
    $("select[id='service_order_appointment']").prop("selectedIndex", 0).val();
}