function delete_loading_ssetting(element){
    element.style.display = "none"
    element.previousElementSibling.style.display = "none"
    element.nextElementSibling.style.display = "block"
  }

  function openFormAddssettings() {
    document.getElementById("form-add-ssettings-container").style.display = "block";
    document.getElementById("cls_bmtu_form_add_title").innerHTML = create_ssetting;
    document.getElementById("btn_add_new_ssettings_buttton").value = btn_create;
    document.getElementById("ssettings_id_add").value = "";
    document.getElementById("maxreg_setting").value = "";
    document.getElementById("hstart_setting").value = "";    
    document.getElementById("hend_setting").value = "";    
    document.getElementById("spriod_setting").value = "";    
    // document.getElementById("holidays_setting").value = ""; s   
    document.getElementById("note_setting").value = "";    

  }

  function closeFormAddssettings() {
    document.getElementById("form-add-ssettings-container").style.display = "none";
    document.getElementById("ssettings_id_add").value = "";
    document.getElementById("maxreg_setting").value = "";
    document.getElementById("hstart_setting").value = "";    
    document.getElementById("hend_setting").value = "";    
    document.getElementById("spriod_setting").value = "";    
    // document.getElementById("holidays_setting").value = "";    
    document.getElementById("note_setting").value = "";  
      
  }

    document.getElementById("btn_add_new_ssettings_buttton").addEventListener("click", function() {
    document.getElementById("btn_add_new_ssetting_buttton").style.display = "none";
    document.getElementById("loading_button_ssetting").style.display = "block";
  })