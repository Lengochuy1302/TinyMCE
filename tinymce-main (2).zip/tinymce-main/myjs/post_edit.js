const mySelect = new Choices('#select_tag', {
    removeItemButton: true,
    choices: arrChoices,
});

const mySelectEn = new Choices('#select_tag_en', {
    removeItemButton: true,
    choices: arrChoicesEn,
});


if (check_noi_bat == 'true') {
    $('#select_noi_bat').prop('checked', true);
}
if (linkImage != "") {
    $('.imagePreview').css('background-image', `url("${linkImage}")`);
}
flatpickr(".date_post", {
    dateFormat: "d/m/Y",
    defaultDate: value_date,
    locale: {
        firstDayOfWeek: 1, // bắt đầu từ thứ 2
        weekdays: {
            shorthand: ["CN", "T2", "T3", "T4", "T5", "T6", "T7"],
            longhand: [
                "Chủ nhật",
                "Thứ hai",
                "Thứ ba",
                "Thứ tư",
                "Thứ năm",
                "Thứ sáu",
                "Thứ bảy",
            ],
        },
        months: {
            shorthand: [
                "Thg 1",
                "Thg 2",
                "Thg 3",
                "Thg 4",
                "Thg 5",
                "Thg 6",
                "Thg 7",
                "Thg 8",
                "Thg 9",
                "Thg 10",
                "Thg 11",
                "Thg 12",
            ],
            longhand: [
                "Tháng 1",
                "Tháng 2",
                "Tháng 3",
                "Tháng 4",
                "Tháng 5",
                "Tháng 6",
                "Tháng 7",
                "Tháng 8",
                "Tháng 9",
                "Tháng 10",
                "Tháng 11",
                "Tháng 12",
            ],
        },
    },
});