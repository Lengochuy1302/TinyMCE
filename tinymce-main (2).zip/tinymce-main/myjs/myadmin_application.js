$('a[data-user-order]').click(function() {
    var data = JSON.parse(JSON.stringify($(this).data('user-order')));
    $('#confirm-title-order').text("Xác nhận khách hàng");
    $('#id_order').val(data.id);
    $('#name_order').text(data.fullname);
    $('#phone_order').text(data.phone);
    $('#service_order').text(data.service);
    $('#date_order').val(data.mdate);
    $('#note-last').html(data.note);
    $('#note-last1').html(data.note);
    $('#note-last2').html(data.note);
    $('input[name="time_order"]').filter(function() {return $(this).val() == data.slot;}).prop('checked', true);
});
$('a[data-user-order-change]').click(function() {
    var data = JSON.parse(JSON.stringify($(this).data('user-order-change')));
    $('#confirm-title-order').text("Thay đổi xác nhận khách hàng");
    $('#id_order').val(data.id);
    $('#name_order').text(data.fullname);
    $('#phone_order').text(data.phone);
    $('#service_order').text(data.service);
    $('#date_order').val(data.mdate);
    $('#note-last').html(data.note);
    $('#note-last1').html(data.note);
    $('#note-last2').html(data.note);
    $('input[name="time_order"]').filter(function() {return $(this).val() == data.slot;}).prop('checked', true);
});
$('.confirm-btn').click(function() {
    setTimeout(() => {
        $('#form_confirm_user').submit();
    }, 100);
});

$('a[data-confirm-delete]').click(function() {
    var data = JSON.parse(JSON.stringify($(this).data('confirm-delete')));
    $('#item-delete').text(data.title);
    $('#modal-confirm-delete').addClass('show');
    $('#btn-confirm-delete').prop('href', data.path)
});
$('.btn-close-confirm-delete').click(function() {
    $('#modal-confirm-delete').removeClass('show');
    $('#cropModal').removeClass('show');
    $('#imageSizeModal').removeClass('show');
    $('#image-crop-btmu').attr('src','');
});
