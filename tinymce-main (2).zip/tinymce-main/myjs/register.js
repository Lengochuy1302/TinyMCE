
  



$(document).ready(function() {
$("#show_hide_password a").on('click', function(event) {
    event.preventDefault();
    if($('#show_hide_password input').attr("type") == "text"){
        $('#show_hide_password input').attr('type', 'password');
        $('#show_hide_password i').addClass( "fa-eye-slash" );
        $('#show_hide_password i').removeClass( "fa-eye" );
    }else if($('#show_hide_password input').attr("type") == "password"){
        $('#show_hide_password input').attr('type', 'text');
        $('#show_hide_password i').removeClass( "fa-eye-slash" );
        $('#show_hide_password i').addClass( "fa-eye" );
    }
});
});
$('#password_txt').val('');
$(document).ready(function() {
    $("#show_hide_password_pwd a").on('click', function(event) {
        event.preventDefault();
        if($('#show_hide_password_pwd input').attr("type") == "text"){
            $('#show_hide_password_pwd input').attr('type', 'password');
            $('#show_hide_password_pwd i').addClass( "fa-eye-slash" );
            $('#show_hide_password_pwd i').removeClass( "fa-eye" );
        }else if($('#show_hide_password_pwd input').attr("type") == "password"){
            $('#show_hide_password_pwd input').attr('type', 'text');
            $('#show_hide_password_pwd i').removeClass( "fa-eye-slash" );
            $('#show_hide_password_pwd i').addClass( "fa-eye" );
        }
    });
    });


    document.getElementById('btn_register_submit').onclick = function (){
        var username =document.getElementById('username_txt').value;
        var error_username= document.getElementById('username_txt');
        var email =document.getElementById('email_txt').value;
        var error_email= document.getElementById('email_txt');
        var password =document.getElementById('password_txt').value;
        var error_password= document.getElementById('password_txt');
        var confirmPassword =document.getElementById('pwd_password_digest_txt').value;
        var error_cf_password= document.getElementById('pwd_password_digest_txt');
        var error_label= document.getElementById('txt_notiMess');

        if (username == "" ) {
            error_username.style.border= "1px solid red";
            error_label.innerHTML = Please_enter_a_username
            error_label.style.display="block";
        
        }
        else if (email == "" ) {
            error_email.style.border= "1px solid red";
            error_label.innerHTML = Please_enter_a_email
            error_label.style.display="block";
        }
        else if (password == "" ) {
            error_password.style.border= "1px solid red";
            error_label.innerHTML = Please_enter_a_password
            error_label.style.display="block";
        }
        else if (confirmPassword != password) {
            error_cf_password.style.border= "1px solid red";
            error_label.innerHTML = Password_incorrect
            error_label.style.display="block";
        }
        else{
          error_label.style.border= "1px solid var(--falcon-input-border-color)";
          error_label.style.display="none";
          document.getElementById("btn_register_submit").type = "submit"
        }
       


    };
    document.getElementById("username_txt").onchange =function(){
        var username= document.getElementById('username_txt').value;
        var error_username= document.getElementById('username_txt');
        var error_label= document.getElementById('txt_notiMess');
        if (username == "" ) {
            error_username.style.border= "1px solid red";
            error_label.innerHTML = Please_enter_a_username
            error_label.style.display="block";
        }else{
            error_username.style.border= "1px solid var(--falcon-input-border-color)";
            error_label.style.display="none";
        }
    }


    document.getElementById("email_txt").onchange =function(){
        var email= document.getElementById('email_txt').value;
        var error_email= document.getElementById('email_txt');
        var error_label= document.getElementById('txt_notiMess');
        if (email == "" ) {
            error_email.style.border= "1px solid red";
            error_label.innerHTML = Please_enter_a_email
            error_label.style.display="block";
        }else{
            error_email.style.border= "1px solid var(--falcon-input-border-color)";
            error_label.style.display="none";
        }
    }

    document.getElementById("password_txt").onchange =function(){
        var password= document.getElementById('password_txt').value;
        var error_password= document.getElementById('password_txt');
        var cf_password= document.getElementById('pwd_password_digest_txt').value;
        var error_cf_password= document.getElementById('pwd_password_digest_txt');
        var error_label= document.getElementById('txt_notiMess');
        if (password == "" ) {
            error_password.style.border= "1px solid red";
            error_label.innerHTML = Please_enter_a_password
            error_label.style.display="block";
        }else{
            error_password.style.border= "1px solid var(--falcon-input-border-color)";
            error_label.style.display="none";
        }
    }
    
    document.getElementById("pwd_password_digest_txt").onchange =function(){
        var cf_password= document.getElementById('pwd_password_digest_txt').value;
        var error_cf_password= document.getElementById('pwd_password_digest_txt');
        var password= document.getElementById('password_txt').value;
        var error_label= document.getElementById('txt_notiMess');
        if (cf_password != password) {
            error_cf_password.style.border= "1px solid red";
            error_label.innerHTML = Password_incorrect;
            error_label.style.display="block";
        }else if (cf_password == "") {
          error_label.innerHTML = Please_enter_a_password
          error_password.style.border= "1px solid red";
          }else{
          error_cf_password.style.border= "1px solid var(--falcon-input-border-color)";
          error_label.style.display="none";
          }
    };





   


 


