tinymce.init({
    selector: '#advpopup_content_add',
    plugins: 'lists advlist anchor autolink autosave autoresize charmap code codesample directionality emoticons fullscreen help image importcss insertdatetime link lists media nonbreaking pagebreak preview quickbars save searchreplace table template visualblocks visualchars wordcount code',
    toolbar1: 'undo redo | blocks fontfamily fontsize | align lineheight | bold italic underline strikethrough forecolor backcolor | image checklist numlist bullist table mergetags | addcomment showcomments | spellcheckdialog a11ycheck typography',
    toolbar2: 'code template | link media indent outdent | emoticons charmap | removeformat',
    table_toolbar: 'tableprops tabledelete | tableinsertrowbefore tableinsertrowafter tabledeleterow | tableinsertcolbefore tableinsertcolafter tabledeletecol',
    autoresize_bottom_margin: 50,
    file_picker_types: 'image',
    /* and here's our custom image picker*/
    file_picker_callback: (cb, value, meta) => {
      const input = document.createElement('input');
      input.setAttribute('type', 'file');
      input.setAttribute('accept', 'image/*');
  
      input.addEventListener('change', (e) => {
        const file = e.target.files[0];
  
        const reader = new FileReader();
        reader.addEventListener('load', () => {
          /*
            Note: Now we need to register the blob in TinyMCEs image blob
            registry. In the next release this part hopefully won't be
            necessary, as we are looking to handle it internally.
          */
          const id = 'blobid' + (new Date()).getTime();
          const blobCache =  tinymce.activeEditor.editorUpload.blobCache;
          const base64 = reader.result.split(',')[1];
          const blobInfo = blobCache.create(id, file, base64);
          blobCache.add(blobInfo);
  
          /* call the callback and populate the Title field with the file name */
          cb(blobInfo.blobUri(), { title: file.name });
        });
        reader.readAsDataURL(file);
      });
  
      input.click();
    },
    automatic_uploads: false,
    relative_urls: false,
    remove_script_host: false,
    extended_valid_elements: 'svg[*],rect[*],circle[*],path[*],g[*],span[class],link[href|rel],style,script[src|type],label[*]',
    valid_elements : '*[*]',
    custom_elements:"style,link,~link",
    templates : [
        {
          title: 'Giao diện popup quảng cáo',
          description: 'Giao diện hiển thị popup cho chiến dịch quảng cáo',
          content: `<div class="popup-content d-flex col-md-5 col-lg-7 col-xl-7 col-xxl-6 flex-column-reverse flex-lg-row align-items-center" style="border-radius: 5px;">
          <div class="col-12 col-lg-6 col-xl-4 col-xxl-4 p-2 form-register">
          <h3 class="m-0 py-2">KH&Aacute;M V&Agrave; TƯ VẤN MIỄN PH&Iacute;</h3>
          <p class="col-11 col-lg-10 text-center" style="margin: 0 auto;">Đăng k&yacute; ngay để nhận tư vấn miễn ph&iacute; v&agrave; nhiều chương tr&igrave;nh ưu đ&atilde;i hấp dẫn</p>
          <form id="form_booking" action="/appointment/order" accept-charset="UTF-8" method="post">
          <div class="col-12 p-2"><input type="text" name="last_name" style="background: none !important;" maxlength="50" placeholder="Họ" id="last_name" class="input-booking form-control"></div>
          <div class="col-12 p-2"><input type="text" name="first_name" style="background: none !important;" maxlength="50" placeholder="T&ecirc;n đệm v&agrave; t&ecirc;n" id="first_name" class="input-booking form-control"></div>
          <div class="col-12 has-error p-2"><input type="tel" id="number_phone" name="number_phone" style="background: none !important;" placeholder="Số điện thoại" class="input-booking form-control" min="0"></div>
          <textarea id="note" name="note" value="" hidden=""></textarea>
          <div class="form-group p-2">
          <div class="col-xs-12 text-center"><button type="button" class="btn btn-color-dental" id="btn_order" style="font-size: 22px; width: 100%; font-weight: 500;"> Đăng k&yacute; ngay </button></div>
          </div>
          </form></div>
          <div><span class="close btnclose">&times;</span> <img src="/popup-cef0c744546e493cf935fcdeeca1c9255436eb088e73378d5c6ab0806c1491f0.jpg" alt="NHA KHOA S&Agrave;I G&Ograve;N B.H ƯU Đ&Atilde;I TH&Aacute;NG 3/2020 (TIN Đ&Atilde; HẾT HẠN KHUYẾN M&Atilde;I)"></div>
          </div>`
        },
      ],
    custom_formats: [
      {
        name: 'fontawesome',
        inline: 'span',
        classes: 'fa'
      }
    ],
    content_scripts: [
        {
            src: "/myjs/tinymce.min.js",
        }
      ],
    setup: function (editor) {
        editor.ui.registry.addButton('fontawesome', {
          icon: 'fa-regular fa-phone',
          tooltip: 'Insert Font Awesome',
          onAction: function (_) {
            editor.insertContent('<i class="fa fa-star"></i>');
          }
        });
    },
    resize: true,
    min_height: 400,
    content_css_cors: true,
    content_css: [
        '/mystyle/about_us.css',
        '/css/bootstrap.min.css',
        '/css/jquery-ui.css',
        '/mystyle/slick.min.css',
        '/mystyle/slick-theme.min.css',
        '/application.css',
        '/css/admin_icon.css',
        '/css/trx_demo_icons.css',
        '/css/animation.css',
        '/css/style.min.css',
        '/css/wc-blocks-vendors-style.css',
        '/css/wc-blocks-style.css',
        '/css/tooltipster.css',
        '/css/tooltipster-light.css',
        '/css/animations.css',
        '/css/booked.css',
        '/css/styles.css',
        '/css/settings.css',
        '/css/fontello.css',
        '/css/trx_addons_icons-embedded.css',
        '/css/swiper.min.css',
        '/css/magnific-popup.min.css',
        '/css/trx_addons.css',
        '/css/trx_addons.animation.css',
        '/css/trx_demo_panels.css',
        '/css/woocommerce-layout.css',
        '/css/woocommerce-smallscreen.css',
        '/css/woocommerce.css',
        '/css/frontend-style.css',
        '/css/all.css',
        '/css/js_composer.min.css',
        '/css/css.css',
        '/css/fontello-embedded.css',
        '/css/style.css',
        '/css/__styles.css',
        '/css/__colors.css',
        '/css/mediaelementplayer-legacy.min.css',
        '/css/wp-mediaelement.min.css',
        '/css/responsive.css',
        '/css/v4-shims.css',
        '/css/all.min.css',
        '/css/css_935.css',
        '/css/dataTables-bootstrap5.min.css',
        '/css/flatpickr.min.css',
        '/css/rs6.css',
        '/css/style_957.css',
        '/css/v4-shims.min.css',
        '/mystyle/application.css',
        '/mystyle/appointment.css',
        '/mystyle/choices.min.css',
        '/mystyle/cropper.min.css',
        '/mystyle/home_index.css',
        '/mystyle/slick-theme.min.css',
        '/mystyle/slick.min.css',
        '/application.css.scss',
        '/daterangepicker.css',
        '/dropzone.min.css',
        '/jquery-ui.css',
        '/prism-okaidia.css',
        '/sessions.scss',
        '/simplebar.min.css',
        '/user-rtl.min.css',
        '/user.min.css',
        '/css/all.min_bt.css',
        '/myjs/home_index.js',
        '/js/3a67e5d2e3.js',
        '/js/bootstrap.bundle.min.js',
        '/js/jquery-3.6.0.js',
        '/myjs/slick.min.js',
        '/js/jquery-ui.js',
        '/js/jquery.validate.js',
        '/myjs/introduc.js',
        '/js/jquery.min.js',
        '/js/jquery-migrate.min.js',
        '/js/rbtools.min.js',
        '/js/rs6.min.js',
        '/js/jquery.blockUI.min.js',
        '/js/woocommerce-add-to-cart.js',
        '/js/frontend-functions.js',



    ],

    importcss_append: true,
    color_map: [
        '#BFEDD2', 'Light Green',
        '#FBEEB8', 'Light Yellow',
        '#F8CAC6', 'Light Red',
        '#ECCAFA', 'Light Purple',
        '#C2E0F4', 'Light Blue',
      
        '#2DC26B', 'Green',
        '#F1C40F', 'Yellow',
        '#E03E2D', 'Red',
        '#B96AD9', 'Purple',
        '#3598DB', 'Blue',
      
        '#169179', 'Dark Turquoise',
        '#E67E23', 'Orange',
        '#BA372A', 'Dark Red',
        '#843FA1', 'Dark Purple',
        '#236FA1', 'Dark Blue',
      
        '#ECF0F1', 'Light Gray',
        '#CED4D9', 'Medium Gray',
        '#95A5A6', 'Gray',
        '#7E8C8D', 'Dark Gray',
        '#34495E', 'Navy Blue',
      
        '#000000', 'Black',
        '#ffffff', 'White'
      ]
});


function delete_loading_advpopup(element){
    element.style.display = "none"
    element.previousElementSibling.style.display = "none"
    element.nextElementSibling.style.display = "block"
  }



function openFormAddAdvpopup() {
    document.getElementById("form-add-advpopup-container").style.display = "block";
    document.getElementById("cls_bmtu_form_add_title").innerHTML = createadvpopup;
    document.getElementById("btn_add_new_advpopup_buttton").value = btn_create;
    document.getElementById("advpopup_id_add").value = "";
    document.getElementById("advpopup_title_add").value = "";
    tinymce.activeEditor.setContent('');

}

function closeFormAddAdvpopup() {
    document.getElementById("form-add-advpopup-container").style.display = "none";
    document.getElementById("advpopup_id_add").value = "";
    document.getElementById("advpopup_title_add").value = "";
    document.getElementById("advpopup_content_add").value = "";   
    document.getElementById("advpopup_title_add").style.border = "1px solid #ced4da";
    document.getElementById('erro_labble_content').style.display = "none";
      
}

$('#btn_add_new_advpopup_buttton').click(function (){
    var title = $('#advpopup_title_add').val();
    if (title=="") {
        $('#advpopup_title_add').attr('style',' border: 1px solid red !important');
        $('#erro_labble_content').html('Bạn hãy nhập title');
        $('#erro_labble_content').css('display', 'block');

    } else {
        $('#advpopup_title_add').attr('style','border: 1px solid #ddd !important');
        $('#erro_labble_content').html('')
        $('#erro_labble_content').css('display', 'none');
        $('#form_add_advpopup').submit();
    }
});

$('#advpopup_title_add').change(function (){
    var title = $('#advpopup_title_add').val();
    if (title=="") {
        $('#advpopup_title_add').attr('style','border:1px solid red 1important');
        $('#erro_labble_content').html('Bạn hãy nhập title');
        $('#erro_labble_content').css('display', 'block');

    } else {
        $('#advpopup_title_add').attr('style',' border: 1px solid #ddd !important');
        $('#erro_labble_content').html('')
        $('#erro_labble_content').css('display', 'none');
    }
})

$('.modal').on('show.bs.modal', function () {
    $('#advpopup_title_add').val('');
    $('#erro_labble_content').html('')
    $('#erro_labble_content').css('display', 'none');
})
$('#myModal').on('shown.bs.modal', function () {
    $('#myInput').trigger('focus')
})
    $("#getCameraSerialNumbers").click(function () {
});
function insertFontAwesomeIcon(iconClass) {
    tinymce.activeEditor.insertContent('<span class="' + iconClass + '"></span>');
  }