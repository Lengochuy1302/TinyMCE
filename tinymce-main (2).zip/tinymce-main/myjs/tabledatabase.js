var optionTableNoFile = {
    "info": false,
    "autoWidth": false,
    columnDefs: [{ targets: 'no-sort', orderable: false }],
    "language": {
        "lengthMenu": "_MENU_",
        "decimal": "",
        "emptyTable": noDataTable,
        "loadingRecords": loadingTable,
        "processing": "",
        "search": "_INPUT_",
        "searchPlaceholder": searchTable,
        "zeroRecords": noMatchingTable,
        "paginate": {
            "first": firstTable,
            "last": lastTable,
            "next": nextTable,
            "previous": previousTable
        }
    },
    "order": [],
    lengthMenu: [
        [5, 10, 25, 50, 100],
        ["5", "10", "25", "50", "100"],
    ],
    pageLength: 25,
    "dom": '<"top"Bf>r<"table-responsive scrollbar"t><"mt-3 d-flex justify-content-center align-items-center"pl>',
    stateSave: true,
}
var optionTableNoFileWidth = {
    "info": false,
    columnDefs: [{ targets: 'no-sort', orderable: false }],
    "language": {
        "lengthMenu": "_MENU_",
        "decimal": "",
        "emptyTable": noDataTable,
        "loadingRecords": loadingTable,
        "processing": "",
        "search": "_INPUT_",
        "searchPlaceholder": searchTable,
        "zeroRecords": noMatchingTable,
        "paginate": {
            "first": firstTable,
            "last": lastTable,
            "next": nextTable,
            "previous": previousTable
        }
    },
    "order": [],
    lengthMenu: [
        [5, 10, 25, 50, 100],
        ["5", "10", "25", "50", "100"],
    ],
    pageLength: 5,
    "dom": '<"top"Bf>r<"table-responsive scrollbar"t><"mt-3 d-flex justify-content-center align-items-center"pl>',
    stateSave: true,
}
var optionTableNoFileBorder = {
    "info": false,
    "autoWidth": false,
    columnDefs: [{ targets: 'no-sort', orderable: false }],
    "language": {
        "lengthMenu": "_MENU_",
        "decimal": "",
        "emptyTable": noDataTable,
        "loadingRecords": loadingTable,
        "processing": "",
        "search": "_INPUT_",
        "searchPlaceholder": searchTable,
        "zeroRecords": noMatchingTable,
        "paginate": {
            "first": firstTable,
            "last": lastTable,
            "next": nextTable,
            "previous": previousTable
        }
    },
    "order": [],
    lengthMenu: [
        [5, 10, 25, 50, 100],
        ["5", "10", "25", "50", "100"],
    ],
    pageLength: 25,
    "dom": '<"top"Bf>r<"table-responsive scrollbar border-start"t><"mt-3 d-flex justify-content-center align-items-center"pl>',
    stateSave: true,
}
var optionTableFile = {
    "autoWidth": false,
    columnDefs: [{ targets: 'no-sort', orderable: false }],
    "language": {
        "lengthMenu": "_MENU_",
        "decimal": "",
        "emptyTable": noDataTable,
        "loadingRecords": loadingTable,
        "processing": "",
        "search": "_INPUT_",
        "info": "Hiển thị _END_ trên _TOTAL_ bản ghi",
        "infoEmpty": "Hiển thị _END_ trên _TOTAL_ bản ghi",
        "searchPlaceholder": searchTable,
        "zeroRecords": noMatchingTable,
        "paginate": {
            "first": firstTable,
            "last": lastTable,
            "next": nextTable,
            "previous": previousTable
        }
    },
    "fnInfoCallback": function(oSettings, iStart, iEnd, iMax, iTotal, sPre) {
        var page = Math.floor(iEnd / 2);
        var total = Math.floor(iTotal / 2);
        return "Hiển thị " + page + " trên " + total + " bản ghi ";
    },
    "order": [],
    lengthMenu: [
        [20, 50, 100],
        ["10", "25", "50"],
    ],
    pageLength: 20,
    "dom": '<"top"Bf>r<"table-responsive scrollbar"t><"mt-3 d-flex justify-content-between align-items-center"i<"d-flex align-items-center"pl><"me-4">>',
    stateSave: true,
}
var optionTableFileBorder = {
    "autoWidth": false,
    columnDefs: [{ targets: 'no-sort', orderable: false }],
    "language": {
        "lengthMenu": "_MENU_",
        "decimal": "",
        "emptyTable": noDataTable,
        "loadingRecords": loadingTable,
        "processing": "",
        "search": "_INPUT_",
        "info": "Hiển thị _END_ trên _TOTAL_ bản ghi",
        "infoEmpty": "Hiển thị _END_ trên _TOTAL_ bản ghi",
        "searchPlaceholder": searchTable,
        "zeroRecords": noMatchingTable,
        "paginate": {
            "first": firstTable,
            "last": lastTable,
            "next": nextTable,
            "previous": previousTable
        }
    },
    "fnInfoCallback": function(oSettings, iStart, iEnd, iMax, iTotal, sPre) {
        var page = Math.floor(iEnd / 2);
        var total = Math.floor(iTotal / 2);
        return "Hiển thị " + page + " trên " + total + " bản ghi ";
    },
    "order": [],
    lengthMenu: [
        [20, 50, 100],
        ["10", "25", "50"],
    ],
    pageLength: 20,
    "dom": '<"top"Bf>r<"table-responsive scrollbar border-start"t><"mt-3 d-flex justify-content-between align-items-center"i<"d-flex align-items-center"pl><"me-4">>',
    stateSave: true,
}



var optionTable = {
    "info": false,
    "autoWidth": false,
    paging: false,
    "searching": false,
    columnDefs: [{ targets: 'no-sort', orderable: false }],
    "language": {
        "lengthMenu": "_MENU_",
        "decimal": "",
        "emptyTable": noDataTable,
        "loadingRecords": loadingTable,
        "processing": "",
        "searchPlaceholder": searchTable,
        "zeroRecords": noMatchingTable,
        "paginate": {
            "first": firstTable,
            "last": lastTable,
            "next": nextTable,
            "previous": previousTable
        }
    },
    "order": [],
    lengthMenu: [
        [5, 10, 25, 50, 100],
        ["5", "10", "25", "50", "100"],
    ],
    pageLength: 25,
    "dom": '<"top"Bf>r<"table-responsive scrollbar"t><"mt-3 d-flex justify-content-center align-items-center"pl>',
    stateSave: true,
}
var optionTableBorder = {
    "info": false,
    "autoWidth": false,
    paging: false,
    "searching": false,
    columnDefs: [{ targets: 'no-sort', orderable: false }],
    "language": {
        "lengthMenu": "_MENU_",
        "decimal": "",
        "emptyTable": noDataTable,
        "loadingRecords": loadingTable,
        "processing": "",
        "searchPlaceholder": searchTable,
        "zeroRecords": noMatchingTable,
        "paginate": {
            "first": firstTable,
            "last": lastTable,
            "next": nextTable,
            "previous": previousTable
        }
    },
    "order": [],
    lengthMenu: [
        [5, 10, 25, 50, 100],
        ["5", "10", "25", "50", "100"],
    ],
    pageLength: 25,
    "dom": '<"top"Bf>r<"table-responsive scrollbar border-start"t><"mt-3 d-flex justify-content-center align-items-center"pl>',
    stateSave: true,
}
var optionTableStyle = {
    "autoWidth": false,
    columnDefs: [{ targets: 'no-sort', orderable: false }],
    "language": {
        "lengthMenu": "_MENU_",
        "decimal": "",
        "emptyTable": noDataTable,
        "loadingRecords": loadingTable,
        "processing": "",
        "search": "_INPUT_",
        "info": "Hiển thị _END_ trên _TOTAL_ bản ghi",
        "infoEmpty": "Hiển thị _END_ trên _TOTAL_ bản ghi",
        "searchPlaceholder": searchTable,
        "zeroRecords": noMatchingTable,
        "paginate": {
            "first": firstTable,
            "last": lastTable,
            "next": nextTable,
            "previous": previousTable
        }
    },
    "order": [],
    lengthMenu: [
        [10, 25, 50],
        ["10", "25", "50"],
    ],
    pageLength: 10,
    "dom": '<"top"Bf>r<"table-responsive scrollbar"t><"mt-3 d-flex justify-content-between align-items-center"i<"d-flex align-items-center"pl><"me-4">>',
    stateSave: true,
}
$(document).ready(function() {
    $('.table').DataTable(optionTable);
    $(".dataTables_length label select").removeAttr('class');
    $(".dataTables_length label select").attr('class', '');
    $('.dataTables_length label select').addClass("btn btn-sm btn-outline-primary dropdown-toggle");
    $('.pagination').addClass("pagination-sm");
});