const image_upload_handler = (blobInfo, progress) => new Promise((resolve, reject) => {
	const xhr = new XMLHttpRequest();
	xhr.withCredentials = false;
	xhr.open('POST', "/upload_file_tinymce");

	xhr.upload.onprogress = (e) => {
		progress(e.loaded / e.total * 100);
	};

	xhr.onload = () => {
		if (xhr.status === 403) {
			reject({
				message: 'HTTP Error: ' + xhr.status,
				remove: true
			});
			return;
		}

		if (xhr.status < 200 || xhr.status >= 300) {
			reject('HTTP Error: ' + xhr.status);
			return;
		}

		const json = JSON.parse(xhr.responseText);

		if (! json || typeof json.location != 'string') {
			reject('Invalid JSON: ' + xhr.responseText);
			return;
		}

		resolve(json.location);
	};

	xhr.onerror = () => {
		reject('Image upload failed due to a XHR Transport error. Code: ' + xhr.status);
	};

	const formData = new FormData();
	formData.append('file', blobInfo.blob(), blobInfo.filename());

	xhr.send(formData);
});

tinymce.init({
	language_url: 'tinymce/langs/vi.js',
	language: 'vi',
	selector: "#mytextarea",
	base_url: "/tinymce",
	plugins: 'codeeditor lists advlist anchor autolink autosave autoresize charmap code codesample directionality emoticons fullscreen image importcss insertdatetime link lists media nonbreaking pagebreak preview quickbars save searchreplace table template visualblocks visualchars wordcount',
	toolbar1: 'undo redo | blocks fontsize | align lineheight | bold italic underline strikethrough forecolor backcolor',
	toolbar2: 'template codeeditor |image checklist numlist bullist table mergetags | addcomment showcomments | spellcheckdialog a11ycheck typography | link media indent outdent',
	table_toolbar: 'tableprops tabledelete | tableinsertrowbefore tableinsertrowafter tabledeleterow | tableinsertcolbefore tableinsertcolafter tabledeletecol',
	content_style: 'body { font-family: "Source Serif 4", sans-serif; }',
	min_height: 700,
	images_upload_handler: image_upload_handler,
	file_picker_types: 'image',
	file_picker_callback: (cb, value, meta) => {
		const input = document.createElement('input');
		input.setAttribute('type', 'file');
		input.setAttribute('accept', 'image/*');

		input.addEventListener('change', (e) => {
			const file = e.target.files[0];

			const reader = new FileReader();
			reader.addEventListener('load', () => {
				const id = 'blobid' + (
					new Date()
				).getTime();
				const blobCache = tinymce.activeEditor.editorUpload.blobCache;
				const base64 = reader.result.split(',')[1];
				const blobInfo = blobCache.create(id, file, base64);
				blobCache.add(blobInfo);
				cb(blobInfo.blobUri(), {title: file.name});
			});
			reader.readAsDataURL(file);
		});

		input.click();
	},
	relative_urls: false,
	remove_script_host: false,
	extended_valid_elements: 'svg[*],rect[*],circle[*],path[*],g[*],span[class],link[href|rel],style,script[src|type],label[*]',
	valid_elements: '*[*],+*[*]',
	custom_elements: "style,link,~link",
	formats: {
		removeformat: [
			{
				selector: '*',
				remove: 'all',
				split: true,
				expand: false,
				block_expand: true,
				deep_merge: true
			}
		]
	},
	init_instance_callback: function (editor) {
		var jqueryScript = "/myjs/bmtu/jquery.min.js";
		var jsPaths = [
			"/myjs/bmtu/bootstrap.bundle.min.js",
			"/myjs/bmtu/jquery.meanmenu.js",
			"/myjs/bmtu/owl.carousel.min.js",
			"/myjs/bmtu/carousel-thumbs.min.js",
			"/myjs/bmtu/jquery.magnific-popup.js",
			"/myjs/bmtu/aos.js",
			"/myjs/bmtu/odometer.min.js",
			"/myjs/bmtu/appear.min.js",
			"/myjs/bmtu/form-validator.min.js",
			"/myjs/bmtu/contact-form-script.js",
			"/myjs/bmtu/ajaxchimp.min.js",
			"/myjs/bmtu/custom.js",
			"/myjs/slick.min.js",
			"/myjs/bmtu/slider_customs.js"
		];

		var loadScript = function (src) {
			return new Promise(function (resolve, reject) {
				var script = editor.dom.create('script', {src: src});
				script.onload = resolve;
				script.onerror = reject;
				editor.getDoc().head.appendChild(script);
			});
		};

		loadScript(jqueryScript).then(function () {
			return jsPaths.reduce(function (prev, path) {
				return prev.then(function () {
					return loadScript(path);
				});
			}, Promise.resolve());
		}).catch(function (error) {
			console.error('Error loading scripts:', error);
		});
	},
	content_css_cors: true,
	content_css: [
		'/mystyle/bmtu/bootstrap.min.css',
		'/mystyle/bmtu/meanmenu.css',
		'/mystyle/bmtu/owl.carousel.min.css',
		'/mystyle/bmtu/owl.theme.default.min.css',
		'/mystyle/bmtu/magnific-popup.css',
		'/mystyle/bmtu/flaticon.css',
		'/mystyle/bmtu/remixicon.css',
		'/mystyle/bmtu/odometer.min.css',
		'/mystyle/bmtu/aos.css',
		'/mystyle/bmtu/style.css',
		'/mystyle/bmtu/dark.css',
		'/mystyle/bmtu/responsive.css',
		'/mystyle/bmtu/bmtu_1.css',
		'/mystyle/bmtu/bmtu_2.css',
		'/mystyle/bmtu/bmtu_3.css',
		'/mystyle/bmtu/bmtu_4.css',
		'/mystyle/bmtu/bmtu_5.css',
		'/mystyle/bmtu/bmtu_6.css',
		'/mystyle/bmtu/bmtu_7.css',
		'/mystyle/bmtu/bmtu_8.css',
		'/mystyle/bmtu/bmtu_9.css',
		'/mystyle/bmtu/bmtu_10.css',
		'/mystyle/bmtu/bmtu_11.css',
		'/mystyle/bmtu/bmtu_12.css',
		'/mystyle/bmtu/bmtu_13.css',
		'/mystyle/bmtu/bmtu_14.css',
		'/mystyle/bmtu/bmtu_15.css',
		'/mystyle/bmtu/bmtu_16.css',
		'/mystyle/bmtu/bmtu_17.css',
		'/mystyle/slick.min.css',
		'/mystyle/slick-theme.min.css',
		'css.css',
		'https://fonts.googleapis.com/css?family=Source Serif 4',
	],
	importcss_append: true,
	color_map: [
		'#BFEDD2',
		'Light Green',
		'#FBEEB8',
		'Light Yellow',
		'#F8CAC6',
		'Light Red',
		'#ECCAFA',
		'Light Purple',
		'#C2E0F4',
		'Light Blue',

		'#2DC26B',
		'Green',
		'#F1C40F',
		'Yellow',
		'#E03E2D',
		'Red',
		'#B96AD9',
		'Purple',
		'#3598DB',
		'Blue',

		'#169179',
		'Dark Turquoise',
		'#E67E23',
		'Orange',
		'#BA372A',
		'Dark Red',
		'#843FA1',
		'Dark Purple',
		'#236FA1',
		'Dark Blue',

		'#ECF0F1',
		'Light Gray',
		'#CED4D9',
		'Medium Gray',
		'#95A5A6',
		'Gray',
		'#7E8C8D',
		'Dark Gray',
		'#34495E',
		'Navy Blue',

		'#000000',
		'Black',
		'#ffffff',
		'White'
	],
    setup: function (editor) {
        // Hàm để áp dụng thuộc tính contenteditable cho các phần tử có class non-editable và add-editable
        function applyEditable() {
            editor.getBody().querySelectorAll('.non-editable').forEach(function (element) {
                element.setAttribute('contenteditable', 'false');
            });

            editor.getBody().querySelectorAll('.add-editable').forEach(function (element) {
                if (!element.querySelector('.add-button')) {
                    var addButton = document.createElement('button');
                    addButton.classList.add('add-button');
                    addButton.textContent = '+';
                    addButton.addEventListener('click', function(e) {
                        e.preventDefault();
                        addItem(element);
                    });
                    element.appendChild(addButton);
                }
                if (!element.querySelector('.remove-button')) {
                    var deleteButton = document.createElement('button');
                    deleteButton.classList.add('remove-button');
                    deleteButton.textContent = '-';
                    deleteButton.addEventListener('click', function(e) {
                        e.preventDefault();
                        deleteItem(element);
                    });
                    element.appendChild(deleteButton);
                }
            });
        }

        // Hàm để thêm item đã cấu hình trước
        function addItem(target) {
            var newItem = target.cloneNode(true);
            newItem.querySelector('.add-button').addEventListener('click', function(e) {
                e.preventDefault();
                addItem(newItem);
            });
            newItem.querySelector('.remove-button').addEventListener('click', function(e) {
                e.preventDefault();
                deleteItem(newItem);
            });
            target.parentNode.insertBefore(newItem, target.nextSibling);
        }

        // Hàm để xóa item
        function deleteItem(target) {
            target.remove();
        }

        // Áp dụng thuộc tính ngay khi khởi tạo
        editor.on('init', function () {
            applyEditable();
        });

        // Chặn các sự kiện kéo thả trên các phần tử không chỉnh sửa
        editor.on('dragstart', function (e) {
            if (e.target.closest('.non-editable')) {
                e.preventDefault();
            }
        });

        editor.on('drop', function (e) {
            if (e.target.closest('.non-editable')) {
                e.preventDefault();
            }
        });

        // Chặn các sự kiện copy, paste và cut trên các phần tử không chỉnh sửa
        editor.on('beforepaste', function (e) {
            if (editor.selection.getNode().closest('.non-editable')) {
                e.preventDefault();
            }
        });

        editor.on('beforecut', function (e) {
            if (editor.selection.getNode().closest('.non-editable')) {
                e.preventDefault();
            }
        });

        editor.on('beforecopy', function (e) {
            if (editor.selection.getNode().closest('.non-editable')) {
                e.preventDefault();
            }
        });

        // Áp dụng lại thuộc tính khi nội dung được thay đổi
        editor.on('SaveContent', function (e) {
            applyEditable();
        });

        // Áp dụng lại thuộc tính khi nội dung được thay đổi từ mã code
        editor.on('change', function (e) {
            applyEditable();
        });
    },
});
